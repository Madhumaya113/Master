package com.example.demo;
import java.io.IOException;
import java.util.Date;
import java.util.Properties;
import java.util.ResourceBundle;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.stereotype.Component;

@Component
public class Mailer {
		private String subject="iCare",to,body;
//		ResourceBundle rb = ResourceBundle.getBundle("db");
		private  String emailUser="codefast75@gmail.com";
		private  String emailPassword="Dhruva@99";
		private String setContent="text/html";
		public Mailer() {
			// TODO Auto-generated constructor stub
		}
		public Mailer(String to ,String subject, String body, String setContent) {
			super();
			this.subject = subject;
			this.to = to;
			this.body = body;
			this.setContent = setContent;
		}

		public String getSetContent() {
			return setContent;
		}

		public void setSetContent(String setContent) {
			this.setContent = setContent;
		}

		public Mailer(String to, String subject, String body) {
			super();
			this.subject = subject;
			this.to = to;
			this.body = body;
		}
		
		public String getBody() {
			return body;
		}

		public void setBody(String body) {
			this.body = body;
		}

//		public String getEmailPassword() throws IOException {
//			ResourceBundle rb = ResourceBundle.getBundle("db");
//			this.emailPassword=rb.getString("emailPassword");
//			if(this.emailPassword==null||this.emailPassword.equals(""))
//			{
//				throw new IOException("Please check your password");
//			}
//			return this.emailPassword;
//		}
//
//		public String getEmailUser() throws IOException {
//			ResourceBundle rb = ResourceBundle.getBundle("db");
//			this.emailUser = rb.getString("emailUser");
//			if(this.emailUser==null||this.emailPassword==null) {
//				throw new IOException("Please check from address");
//			}
//			return this.emailUser;
//		}

		public String getSubject() {
			return subject;
		}

		public void setSubject(String subject) {
			this.subject = subject;
		}
		public String getTo() {
			return to;
		}

		public void setTo(String to) {
			this.to = to;
		}

		public Integer sendEmail() {
			Properties props = new Properties();
			props.put("mail.smtp.host", "true");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.host", "smtp.gmail.com");
			props.put("mail.smtp.port", "587");
			props.put("mail.smtp.auth", "true");
			//Establishing a session with required user details
			Session session = Session.getInstance(props, new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(emailUser, emailPassword);
				}
			});
			try {

				MimeMessage msg = new MimeMessage(session);
				System.out.println("hii5");
				InternetAddress[] address = InternetAddress.parse(to, true);
				msg.setRecipients(Message.RecipientType.TO, address);
				msg.setSubject(this.subject);
				msg.setSentDate(new Date());
				msg.setContent(body,setContent);
//				msg.setText(mailer.getBody());
				msg.setHeader("XPriority", "1");

				Transport.send(msg);
				System.out.println("Mail has been sent successfully");
			} catch (MessagingException mex) {
				System.out.println("Unable to send an email:\n" + mex);
			}
			return 1;
		}
	}

