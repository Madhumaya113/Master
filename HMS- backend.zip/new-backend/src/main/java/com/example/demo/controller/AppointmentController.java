package com.example.demo.controller;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.entity.Appointment;
import com.example.demo.service.AppointmentService;

@RestController
@RequestMapping("/appointment")
@CrossOrigin(value = "*")
public class AppointmentController {
	@Autowired
	private AppointmentService appointmentService;
	@GetMapping("/")
	public List<Appointment> findAllAppointment() {
		return appointmentService.read();
	}
	//http://localhost/3/id
	//http://localhost/user/2/fb
	//http://localhost/user/1/fb
	@GetMapping("/{id}")
	public Appointment findAppointmentById(@PathVariable("id") Integer id) {
		return appointmentService.read(id);
	}
	@PostMapping("/{id}")
	public Appointment createAppointment(@PathVariable("id")Integer id,@RequestBody Appointment appointment) {
		appointment.setPatientId(id);
		appointment.setStatus("pending");
		appointment.setCreatedOn(new Date());
		appointment.setUpdatedOn(new Date());
		return appointmentService.create(appointment);
	}
	@PutMapping("/")
	public Appointment updateAppointment(@RequestBody Appointment appointment) {
		appointment.setUpdatedOn(new Date());
		return appointmentService.update(appointment);
	}
	@DeleteMapping("/{id}")
	public void deleteAppointment(@PathVariable("id") Integer appointment) {
		appointmentService.delete(findAppointmentById(appointment));
	}
	
	@GetMapping("/find")
	public List<Appointment> getPatientAppointment(@RequestParam(name = "patient") Integer id) {
		List<Appointment> res = appointmentService.getUserAppointment(id);
		for(Appointment r:res) {
			System.out.println(r);
		}
		return res;
	}
	
	 @PostMapping("/reshedule")
     public Integer resheduleAppointment(@RequestBody Appointment appointment) {
     return appointmentService.rescheduleAppointment(appointment.getAppointmentId(), appointment.getAppointmentDate(),
             appointment.getTimeSlot());   
	 }
	 
	 @GetMapping("/cancel/{id}")
	 public Integer cancelAppointment(@PathVariable("id")Integer id) {
		 return appointmentService.cancelAppointment(id);
	 }
}
