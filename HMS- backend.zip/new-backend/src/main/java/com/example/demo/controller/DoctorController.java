package com.example.demo.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Doctor;
import com.example.demo.service.DoctorService;

@RestController
@RequestMapping("/doctor")
@CrossOrigin(value = "*")
public class DoctorController {
	@Autowired
	private DoctorService doctorService;
	@GetMapping("/")
	public List<Doctor> findAllDoctor() {
		return doctorService.read();
	}
	@GetMapping("/{id}")
	public Doctor findDoctorById(@PathVariable("id") Integer id) {
		return doctorService.read(id);
	}
	@PostMapping("/")
	public Doctor createDoctor(@RequestBody Doctor doctor) {
		doctor.setCreatedOn(new Date());
		doctor.setUpdatedOn(new Date());
		return doctorService.create(doctor);
	}
	@PutMapping("/")
	public Doctor updateDoctor(@RequestBody Doctor doctor) {
		doctor.setUpdatedOn(new Date());
		return doctorService.update(doctor);
	}
	@DeleteMapping("/{id}")
	public void deleteDoctor(@PathVariable("id") Integer doctor) {
		doctorService.delete(findDoctorById(doctor));
	}
	@GetMapping("/find")
	public List<Object> findDoctor(@RequestParam(name = "name",required = false,defaultValue = "null") String name,@RequestParam(name = "specialization",required = false,defaultValue = "null") String specialization) {
		if(!name.equals("null")) {
			System.out.println("this 1 block is called");
			return doctorService.findDoctorByName(name);
		}
		if(!specialization.equals("null"))
			return doctorService.findDoctorBySpecialization(specialization);
		return doctorService.findDoctorWithDetails();
	}
	
}
