package com.example.demo.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Mailer;
import com.example.demo.entity.Employee;
import com.example.demo.entity.Patient;
import com.example.demo.entity.User;
import com.example.demo.service.EmployeeService;
import com.example.demo.service.UserService;

@RestController
@RequestMapping("/employee")
@CrossOrigin(value = "*")
public class EmployeeController {
	@Autowired
	private EmployeeService employeeService;

	@Autowired
	private UserService userService;
	@GetMapping("/")
	public List<Employee> findAllEmployee() {
		return employeeService.read();
	}
	@GetMapping("/{id}")
	public Employee findEmployeeById(@PathVariable("id") Integer id) {
		return employeeService.read(id);
	}
	@PostMapping("/")
	public Employee createEmployee(@RequestBody Employee employee,HttpSession session) {
		employee.setCreatedOn(new Date());
		employee.setUpdatedOn(new Date());
		System.out.println(employee);
		User user = new User();
		user.setUserName(employee.getEmail());
		String defaultPassword = employee.getFirstName().substring(0, 3)+
				employee.getLastName().substring(0,3)+employee.getContactNo().toString().substring(5, 9);
		user.setPassword(defaultPassword);
		String body="<h3>Account created successfully</h3><br><b>Your credentials are below<br>"
				+ "User Name : "+employee.getEmail()+"</b>"
				+ "Password : "+defaultPassword;
		Mailer mailer = new Mailer(employee.getEmail(), "Account created successfully", body);
		mailer.sendEmail();
		user.setRole(1);
		User res = userService.create(user);
		Employee emp=null;
		if(res!=null)
			{
			emp =  employeeService.create(employee);
			session.setAttribute("userId", emp.getEmpId());
			session.setAttribute("user_role", "doctor_role");
			}
		return emp;
	}
	@PutMapping("/")
	public Employee updateEmployee(@RequestBody Employee employee) {
		employee.setUpdatedOn(new Date());
		return employeeService.update(employee);
	}
	@DeleteMapping("/{id}")
	public void deleteEmployee(@PathVariable("id") Integer id) {
		employeeService.delete(employeeService.read(id));
	}
	
	@GetMapping("/find-unmapped")
	public List<Employee> findUnmapped() {
		return employeeService.getUnmappedDoctors();
	}
	
}
