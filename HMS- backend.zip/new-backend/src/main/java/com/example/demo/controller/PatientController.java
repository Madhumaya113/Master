package com.example.demo.controller;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Appointment;
import com.example.demo.entity.Patient;
import com.example.demo.entity.User;
import com.example.demo.service.AppointmentService;
import com.example.demo.service.PatientService;
import com.example.demo.service.UserService;

@RestController
@RequestMapping("/patient")
@CrossOrigin(value = "*")
public class PatientController {
	@Autowired
	private PatientService patientService;
	@Autowired
	private AppointmentService appointmentService;
	@Autowired
	private UserService userService;
	@GetMapping("/")
	public List<Patient> findAllPatient() {
		return patientService.read();
	}
	@GetMapping("/{id}")
	public Patient findPatientById(@PathVariable("id") Integer id) {
		return patientService.read(id);
	}
	@PostMapping("/")
	public Patient createPatient(@RequestBody Patient patient) {
		patient.setCreatedOn(new Date());
		patient.setUpdatedOn(new Date());
		User user=new User();
		user.setUserName(patient.getEmail());
		user.setPassword(patient.getPassword());
		user.setRole(0);
		User res = userService.create(user);
		Patient patent=null;
		if(res!=null)
			patent = patientService.create(patient);
		return patent;
	}
	@PutMapping("/")
	public Patient updatePatient(@RequestBody Patient patient) {
		patient.setUpdatedOn(new Date());
		return patientService.update(patient);
	}
	@DeleteMapping("/{id}")
	public void deletePatient(@PathVariable Integer patient) {
		patientService.delete(findPatientById(patient));
	}
	@PostMapping("/appointments/{id}")
	public List<Appointment> getAppointments(@PathVariable Integer id) {
		return appointmentService.getUserAppointment(id);
	}
}
