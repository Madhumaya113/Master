package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Prescription;
import com.example.demo.service.PrescriptionService;

@RestController
@RequestMapping("/prescription")
@CrossOrigin(value = "*")
public class PrescriptionController {
	@Autowired
	private PrescriptionService prescriptionService;
	@GetMapping("/")
	public List<Prescription> findAllPrescription() {
		return prescriptionService.read();
	}
	@GetMapping("/{id}")
	public Prescription findPrescriptionById(@PathVariable("id") Integer id) {
		return prescriptionService.read(id);
	}
	@PostMapping("/")
	public Prescription createPrescription(@RequestBody Prescription prescription) {
		return prescriptionService.create(prescription);
	}
	@PutMapping("/")
	public Prescription updatePrescription(@RequestBody Prescription prescription) {
		return prescriptionService.update(prescription);
	}
	@DeleteMapping("/{id}")
	public void deletePrescription(@PathVariable("id") Integer prescription) {
		prescriptionService.delete(findPrescriptionById(prescription));
	}
	@GetMapping("/find")
    public List<Object> getPrescriptionDetails(@RequestParam(required = true,name = "id")int id) {
        return prescriptionService.getPrescriptionWithDetails(id);
	}
}
