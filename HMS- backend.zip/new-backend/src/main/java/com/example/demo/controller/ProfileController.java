package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Profile;
import com.example.demo.service.ProfileService;

@RestController
@RequestMapping("/profile")
@CrossOrigin(value = "*")
public class ProfileController {
	@Autowired
	private ProfileService profileService;
	@GetMapping("/")
	public List<Profile> findAllProfile() {
		return profileService.read();
	}
	@GetMapping("/{id}")
	public Profile findProfileById(@PathVariable("id") Integer id) {
		return profileService.read(id);
	}
	@PostMapping("/")
	public Profile createProfile(@RequestBody Profile profile) {
		return profileService.create(profile);
	}
	@PutMapping("/")
	public Profile updateProfile(@RequestBody Profile profile) {
		return profileService.update(profile);
	}
	@DeleteMapping("/{id}")
	public void deleteProfile(@PathVariable("id") Integer profile) {
		profileService.delete(findProfileById(profile));
	}
}
