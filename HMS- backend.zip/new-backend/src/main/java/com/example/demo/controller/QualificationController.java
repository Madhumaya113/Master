package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Qualification;
import com.example.demo.service.QualificationService;

@RestController
@RequestMapping("/qualification")
@CrossOrigin(value = "*")
public class QualificationController {
	@Autowired
	private QualificationService qualificationService;
	@GetMapping("/")
	public List<Qualification> findAllQualification() {
		return qualificationService.read();
	}
	@GetMapping("/{id}")
	public Qualification findQualificationById(@PathVariable("id") Integer id) {
		return qualificationService.read(id);
	}
	@PostMapping("/{id}")
	public Qualification createQualification(@PathVariable("id") Integer id,@RequestBody Qualification qualification) {
		System.out.println(qualification);	
		qualification.setEmpId(id);
		System.out.println(qualification);
		return qualificationService.create(qualification);
	}
	
	@PutMapping("/")
	public Qualification updateQualification(@RequestBody Qualification qualification) {
		return qualificationService.update(qualification);
	}
	@DeleteMapping("/{id}")
	public void deleteQualification(@PathVariable("id") Integer id) {
		qualificationService.delete(qualificationService.read(id));
	}
	@GetMapping("/find")
	public List<Qualification> findQualifcationByEmpId(@RequestParam("empId") Integer empId) {
		return qualificationService.getEmployeeQualification(empId);
	}
	
}
