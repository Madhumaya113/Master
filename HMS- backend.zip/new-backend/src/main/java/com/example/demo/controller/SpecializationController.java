package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Specialization;
import com.example.demo.service.SpecializationService;

@RestController
@RequestMapping("/specialization")
@CrossOrigin(value = "*")
public class SpecializationController {
	@Autowired
	private SpecializationService specializationService;
	@GetMapping("/")
	public List<Specialization> findAllSpecialization() {
		
		return specializationService.read();
	}
	@GetMapping("/{id}")
	public Specialization findSpecializationById(@PathVariable("id") Integer id) {
		return specializationService.read(id);
	}
	@PostMapping("/")
	public Specialization createSpecialization(@RequestBody Specialization specialization) {
		return specializationService.create(specialization);
	}
	@PutMapping("/")
	public Specialization updateSpecialization(@RequestBody Specialization specialization) {
		return specializationService.update(specialization);
	}
	@DeleteMapping("/{id}")
	public void deleteSpecialization(@PathVariable("id") Integer specialization) {
		specializationService.delete(findSpecializationById(specialization));
	}
}
