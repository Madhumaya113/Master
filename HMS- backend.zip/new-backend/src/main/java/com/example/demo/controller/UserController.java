package com.example.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Mailer;
import com.example.demo.entity.User;
import com.example.demo.service.DoctorService;
import com.example.demo.service.PatientService;
import com.example.demo.service.UserService;

@RestController
@RequestMapping("/user")
@CrossOrigin(value = "*")
public class UserController {
	private int oneTimePassword;
	
	public int getOneTimePassword() {
		return oneTimePassword;
	}
	public void setOneTimePassword(int oneTimePassword) {
		this.oneTimePassword = oneTimePassword;
	}
	private static final String Map = null;
	@Autowired
	private UserService userService;
	@Autowired
	private PatientService patientService;
	@Autowired
	private DoctorService doctorService;
	@GetMapping("/")
	public List<User> findAllUser() {
		return userService.read();
	}
	@GetMapping("/{id}")
	public User findUserById(@PathVariable("id") Integer id) {
		return userService.read(id);
	}
	@PostMapping("/")
	public User createUser(@RequestBody User user) {
		return userService.create(user);
	}
	@PutMapping("/")
	public User updateUser(@RequestBody User user) {
		return userService.update(user);
	}
	@DeleteMapping("/")
	public void deleteUser(@RequestBody User user) {
		userService.delete(user);
	}
	@PostMapping("/auth")
	public HashMap<String, String> authUser(@RequestBody User user,HttpSession session) {
		User res = userService.getUserByUsername(user.getUserName());
		if(res==null)
			return null;
		Integer id=null;
		String role="";
		HashMap <String,String> map= new HashMap<>();
		if(res.getPassword().equals(user.getPassword())&& res.getPassword()!=null) {
			switch(res.getRole()) {
			case 0 : id = patientService.getPatientId(user.getUserName());role="Patient"; System.out.println("success"); break;
			case 1 : id = doctorService.getDoctorId(res.getUserName());role="Physician";System.out.println("Doctor Login");break;
			case 2 : id = res.getId();System.out.println("Admin");role="Admin";break;
			}
			System.out.println(id);
			if(id==null) {
				return null;
			}else {
				map.put("id", id+"");
				map.put("user_role", role);
				return map;
			}
		}
		return null;
	}
	
	
//	user/forget-password/dhruvasom75@gmail.com
	@GetMapping("/forget-password/{email}")
	public void forgotPassword(@PathVariable("email")String email ) {
		System.out.println(email+"called");
		
		int otp1 =(int) Math.floor(Math.random()*1000);
        System.out.println("OTP" +otp1);     
         String otp=" OTP :  " +otp1;
         Mailer m = new Mailer(email, "Password reset", otp);
         Integer res = m.sendEmail();
         if(res==1) {
        	 setOneTimePassword(otp1);
        	 System.out.println("done");
         }
         else {
        	 System.out.println("Failure");
         }   
	}
	@GetMapping("/reset-password")
	public int resetPassword(@RequestParam(value = "email",required = true)String email,
			@RequestParam(value = "otp",required = true) Integer otp,@RequestParam(value="password",required = true)String password) {
		int otp1 = getOneTimePassword();
		System.out.println(otp1);
		if(otp1==otp) {
			System.out.println("inside");
			int resp = userService.updatePassword(password, email);
			System.out.print(resp);
			return resp;
		}
		return 0;
	}
	
}
