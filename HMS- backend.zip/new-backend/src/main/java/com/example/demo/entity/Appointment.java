package com.example.demo.entity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Appointment {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer appointmentId;
	private Integer patientId;
	private Integer doctorId;
	private Date appointmentDate;
	private String Description;
	@Basic
	@Temporal(TemporalType.TIME)
	private Date timeSlot;
	private String status;
	private byte[] attachment;
	private Date createdOn,updatedOn;
	private String treatmentId;
	public Appointment() {
	}
	
	public Appointment(Integer appointmentId, Integer patientId, Integer doctorId, Date appointmentDate, Date timeSlot,
			String status, byte[] attachment, Date createdOn, Date updatedOn, String treatmentId) {
		super();
		this.appointmentId = appointmentId;
		this.patientId = patientId;
		this.doctorId = doctorId;
		this.appointmentDate = appointmentDate;
		this.timeSlot = timeSlot;
		this.status = status;
		this.attachment = attachment;
		this.createdOn = createdOn;
		this.updatedOn = updatedOn;
		this.treatmentId=treatmentId;
	}
	
	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	public String getTreatmentId() {
		return treatmentId;
	}

	public void setTreatmentId(String treatmentId) {
		this.treatmentId = treatmentId;
	}

	@Override
	public String toString() {
		String res = "";
		if(attachment!=null)
			res=attachment.length+" KB";
		else
			res="Not available";
		return "Appointment("+appointmentId+") \n\t{\n\tappointmentId -> " + appointmentId + 
				"\n\tPatient Id -> " + patientId + 
				"\n\tDoctor Id -> " + doctorId+ 
				"\n\tTreatment Id -> " + treatmentId+ 
			//	"\n\tAppointment Date -> " + DateFormater.defaultDateFormat(appointmentDate)  + 
				//"\n\tTime -> " + DateFormater.timeFormat(timeSlot)  + 
				"\n\tStatus -> " + status+ 
				"\n\tAttachment -> " + res + 
				//"\n\tCreatedOn -> " + DateFormater.defaultDateFormat(createdOn) + 
				//"\n\tUpdatedOn -> "+ DateFormater.defaultDateFormat(updatedOn) + 
				"\n\t}";
	}
	public Appointment(Integer patientId, Integer doctorId, Date appointmentDate, Date timeSlot, String status,
			byte[] attachment,String treatmentId) {
		super();
		this.patientId = patientId;
		this.doctorId = doctorId;
		this.appointmentDate = appointmentDate;
		this.timeSlot = timeSlot;
		this.status = status;
		this.attachment = attachment;
		this.treatmentId=treatmentId;
	}
	public Appointment(Integer patientId, Integer doctorId, Date appointmentDate, String timeSlot, String status,
			byte[] attachment,String treatmentId) throws ParseException {
		super();
		this.patientId = patientId;
		this.doctorId = doctorId;
		this.appointmentDate = appointmentDate;
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
		this.timeSlot = sdf.parse(timeSlot);
		this.status = status;
		this.attachment = attachment;
		this.treatmentId=treatmentId;
	}
	public Integer getAppointmentId() {
		return appointmentId;
	}
	public void setAppointmentId(Integer appointmentId) {
		this.appointmentId = appointmentId;
	}
	public Integer getPatientId() {
		return patientId;
	}
	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}
	public Integer getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(Integer doctorId) {
		this.doctorId = doctorId;
	}
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public Date getTimeSlot() {
		return timeSlot;
	}
	public void setTimeSlot(Date timeSlot) {
		this.timeSlot = timeSlot;
	}
	public void setTimeSlot(String timeSlot) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
		this.timeSlot = sdf.parse(timeSlot);
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public byte[] getAttachment() {
		return attachment;
	}
	public void setAttachment(byte[] attachment) {
		this.attachment = attachment;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public Date getUpdatedOn() {
		return updatedOn;
	}
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}
	
}
