package com.example.demo.entity;
//DID                  NOT NULL VARCHAR2(6)   
//DOCTORSPECIALIZATION          VARCHAR2(50)  
//EXPERIENCE                    VARCHAR2(20)  
//QUALIFICATION                 VARCHAR2(50)  
//achievement                  VARCHAR2(300) 
//CREATEDON                     DATE          
//UPDATEDON                     DATE          

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.xml.crypto.Data;

//import com.mphasis.dbutil.DateFormater;
@Entity
public class Doctor {
    @Override
	public String toString() {
		return "Doctors("+dId+") \n\t{"
				+"\n\tDoctor Id -> " + dId + 
				"\n\tEmployee Id -> " + empId + 
				"\n\tExperience -> " + experience + 
				"\n\tachievement -> " + achievement + 
				//"\n\tCreated On -> " + DateFormater.defaultDateFormat(createdOn)  + 
				//"\n\tUpdated On -> " + DateFormater.defaultDateFormat(updatedOn) + 
				"\n\t}";
	}
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer dId;
    private String empId;
    private String experience;
    private String achievement;
    private Integer specialization;
    private Date createdOn;
	private Date updatedOn;
	public  Doctor() {}
	public Integer getSpecialization() {
		return specialization;
	}
	public void setSpecialization(Integer specialization) {
		this.specialization = specialization;
	}
	
	public Doctor(Integer dId, String empId, String experience,Integer specialization, String achievement, Date createdOn, Date updatedOn) {
		super();
		this.dId = dId;
		this.empId = empId;
		this.specialization = specialization;
		this.experience = experience;
		this.achievement = achievement;
		this.createdOn = createdOn;
		this.updatedOn = updatedOn;
	}
	public Doctor(Integer dId, String empId, String experience, String achievement, Date createdOn, Date updatedOn) {
		super();
		this.dId = dId;
		this.empId = empId;
		this.experience = experience;
		this.achievement = achievement;
		this.createdOn = createdOn;
		this.updatedOn = updatedOn;
	}
	public Doctor(String empId, String experience, String achievement, Date createdOn, Date updatedOn) {
		super();
		this.empId = empId;
		this.experience = experience;
		this.achievement = achievement;
		this.createdOn = createdOn;
		this.updatedOn = updatedOn;
	}
	public Integer getdId() {
		return dId;
	}
	public void setdId(Integer dId) {
		this.dId = dId;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getExperience() {
		return experience;
	}
	public void setExperience(String experience) {
		this.experience = experience;
	}
	public String getAchievement() {
		return achievement;
	}
	public void setAchievement(String achievement) {
		this.achievement = achievement;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public Date getUpdatedOn() {
		return updatedOn;
	}
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}
		
}
