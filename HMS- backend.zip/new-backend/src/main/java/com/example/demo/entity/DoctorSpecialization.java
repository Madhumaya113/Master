package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class DoctorSpecialization {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer docSpecId;
	private Integer docId;
	private Integer specId;
	
	public DoctorSpecialization()
	{}
	
	
	public DoctorSpecialization(Integer docSpecId, Integer docId, Integer specId) {
		super();
		this.docSpecId = docSpecId;
		this.docId = docId;
		this.specId = specId;
	}
	
	public DoctorSpecialization( Integer docId, Integer specId) {
		super();
		
		this.docId = docId;
		this.specId = specId;
	}


	public Integer getDocSpecId() {
		return docSpecId;
	}


	public void setDocSpecId(Integer docSpecId) {
		this.docSpecId = docSpecId;
	}


	public Integer getDocId() {
		return docId;
	}


	public void setDocId(Integer docId) {
		this.docId = docId;
	}


	public Integer getSpecId() {
		return specId;
	}


	public void setSpecId(Integer specId) {
		this.specId = specId;
	}


	@Override
	public String toString() {
		return	"DoctorSpecialization("+docSpecId+") \n\t{\n\tId ->" +docSpecId+ 
				", \n\tDoctor Id -> " + docId+ 
				", \n\tSpecialization Id -> " + specId + 
				"\n\t}";
	}
	
	
}