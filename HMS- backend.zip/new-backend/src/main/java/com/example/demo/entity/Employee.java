package com.example.demo.entity;

import java.util.Arrays;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Transient;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.service.ProfileService;

//import com.mphasis.dbutil.DateFormater;

@Entity
public class Employee {
	
	@Autowired
	@Transient
	private ProfileService profileService;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer empId;
	private String firstName;
	private String lastName;
	private Date dateOfBirth;
	private String gender;
	
	private Integer profile;
	@Override
	public String toString() {
		return "Employee [profileService=" + profileService + ", empId=" + empId + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", dateOfBirth=" + dateOfBirth + ", gender=" + gender + ", profile="
				+ profile + ", email=" + email + ", password=" + password + ", contactNo=" + contactNo + ", address="
				+ address + ", createdOn=" + createdOn + ", updatedOn="
				+ updatedOn + "]";
	}
	private String email;
	private String password;
	private String contactNo;
	private String address;
	private byte[] image;	
	private Date createdOn;
	private Date updatedOn;
	public Employee() {
	}
	
	public Employee(Integer empId, String firstName, String lastName, Date dateOfBirth, String gender, Integer profile,
			String email, String password, String contactNo, String address, byte[] image, Date createdOn,
			Date updatedOn) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.gender = gender;
		this.profile = profile;
		this.email = email;
		this.password = password;
		this.contactNo = contactNo;
		this.address = address;
		this.image = image;
		this.createdOn = createdOn;
		this.updatedOn = updatedOn;
	}
	
	public Employee(String firstName, String lastName, Date dateOfBirth, String gender, Integer profile, String email,
			String password, String contactNo, String address, byte[] image, Date createdOn, Date updatedOn) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.gender = gender;
		this.profile = profile;
		this.email = email;
		this.password = password;
		this.contactNo = contactNo;
		this.address = address;
		this.image = image;
		this.createdOn = createdOn;
		this.updatedOn = updatedOn;
	}
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	
	public void setProfile(Integer profile) {
		this.profile=profile;
	}
	
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Integer getProfile() {
		return profile;
	}

	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public byte[] getImage() {
		return image;
	}
	public void setImage(byte[] image) {
		this.image = image;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public Date getUpdatedOn() {
		return updatedOn;
	}
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}
	
}
