package com.example.demo.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Payment {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer payID;
	private Integer appointmentId;
	private Long amount;
	private String paymentType;
	private Date createdOn;
	public Payment() {
	}
	public Payment(Integer payID, Integer appointmentId, Long amount, String paymentType, Date createdOn) {
		super();
		this.payID = payID;
		this.appointmentId = appointmentId;
		this.amount = amount;
		this.paymentType = paymentType;
		this.createdOn = createdOn;
	}
	public Payment(Integer payID, Integer appointmentId, Long amount, String paymentType) {
		super();
		this.payID = payID;
		this.appointmentId = appointmentId;
		this.amount = amount;
		this.paymentType = paymentType;
	}
	public Integer getPayID() {
		return payID;
	}
	public void setPayID(Integer payID) {
		this.payID = payID;
	}
	public Integer getAppointmentId() {
		return appointmentId;
	}
	public void setAppointmentId(Integer appointmentId) {
		this.appointmentId = appointmentId;
	}
	public Long getAmount() {
		return amount;
	}
	public void setAmount(Long amount) {
		this.amount = amount;
	}
	public String getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	@Override
	public String toString() {
		return "Payment(payID) \n\t{\n\tpayID -> " + payID + 
				", \n\tappointmentId -> " + appointmentId + 
				", \n\tamount -> " + amount + 
				", \n\tpaymentType -> "+ paymentType + 
				", \n\tcreatedOn -> " + createdOn + 
				"\n\t}";
	}

}
