package com.example.demo.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Prescription {
	@Override
	public String toString() {
		return "Prescription("+presId+") \n\t{"+ 
				"\n\tPrescription Id  -> " + presId + 
				"\n\tAppointment Id -> " + 	appointmentId + 
				"\n\tPrescription Document -> "+ prescription.length +"bytes"+ 
				"\n\tDescription -> " + description + 
			//	"\n\tCreated ON -> " + DateFormater.defaultDateFormat(createdON)+ 
			//	"\n\tUpdated On -> " +DateFormater.defaultDateFormat(updatedOn) + 
				"\n\t}";
	}
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer presId;
	private Integer appointmentId;
	private byte[] prescription;
	private String description;
	private Date createdON,updatedOn;

	public Prescription() {}

	public Prescription(Integer presId, Integer appointmentId, byte[] prescription, String description, Date createdON,
			Date updatedOn) {
		super();
		this.presId = presId;
		this.appointmentId = appointmentId;
		this.prescription = prescription;
		this.description = description;
		this.createdON = createdON;
		this.updatedOn = updatedOn;
	}

	public Prescription(Integer appointmentId, byte[] prescription, String description, Date createdON, Date updatedOn) {
		super();
		this.appointmentId = appointmentId;
		this.prescription = prescription;
		this.description = description;
		this.createdON = createdON;
		this.updatedOn = updatedOn;
	}

	public Integer getPresId() {
		return presId;
	}

	public void setPresId(Integer presId) {
		this.presId = presId;
	}

	public Integer getAppointmnetId() {
		return appointmentId;
	}

	public void setAppointmnetId(Integer appointmentId) {
		this.appointmentId = appointmentId;
	}

	public byte[] getPrescription() {
		return prescription;
	}

	public void setPrescription(byte[] prescription) {
		this.prescription = prescription;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getCreatedON() {
		return createdON;
	}

	public void setCreatedON(Date createdON) {
		this.createdON = createdON;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

}
