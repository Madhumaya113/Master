package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.DynamicInsert;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import net.bytebuddy.implementation.bind.annotation.Default;

@Entity
@JsonIgnoreProperties
public class Profile {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer profileId;
	private String profileName;
	@JsonCreator
	public Profile(){}
	public Profile(Integer profileId, String profileName) {
		super();
		
		this.profileId = profileId;
		this.profileName = profileName;
	}
	public Integer getProfileId() {
		return profileId;
	}
	public void setProfileId(int profileId) {
		this.profileId = profileId;
	}
	public void setProfileId(String profileId) {
		this.profileId = Integer.valueOf(profileId);
	}
	public String getProfileName() {
		return profileName;
	}
	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}
	@Override
	public String toString() {
		return "Profile ("+profileId+")\n\t{"+ 
				"\n\tProfile Id -> " + profileId + 
				",\n\tProfile Name -> " + profileName + 
				"\n\t}";
	}

}
