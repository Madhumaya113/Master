package com.example.demo.entity;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

 @Entity
public class Qualification {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer qualId;
	private Integer empId;
	private String qualification;
	private String instituteName;
	private Date procurementYear;
	
	
	public Qualification()
	{}


	public Integer getQualId() {
		return qualId;
	}


	public void setQualId(Integer qualId) {
		this.qualId = qualId;
	}


	public Integer getEmpId() {
		return empId;
	}


	public void setEmpId(Integer empId) {
		this.empId = empId;
	}


	public String getQualification() {
		return qualification;
	}


	public void setQualification(String qualification) {
		this.qualification = qualification;
	}


	public String getInstituteName() {
		return instituteName;
	}


	public void setInstituteName(String instituteName) {
		this.instituteName = instituteName;
	}


	public Date getProcurementYear() {
		return procurementYear;
	}


	public void setProcurementYear(Date procurementYear) {
		this.procurementYear = procurementYear;
	}


	public Qualification(Integer qualId, Integer empId, String qualification, String instituteName,
			Date procurementYear) {
		super();
		this.qualId = qualId;
		this.empId = empId;
		this.qualification = qualification;
		this.instituteName = instituteName;
		this.procurementYear = procurementYear;
	}


	@Override
	public String toString() {
		return "Qualification [qualId=" + qualId + ", empId=" + empId + ", qualification=" + qualification
				+ ", instituteName=" + instituteName + ", procurementYear=" + procurementYear + "]";
	}
	
}
