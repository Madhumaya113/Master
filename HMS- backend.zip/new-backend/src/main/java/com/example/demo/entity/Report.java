package com.example.demo.entity;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Report {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer reportId;
	private Integer appointmentId;
	private Date reportDate,time;
	private byte[] reportImage;
	private Date createdOn;
	private String title;
	public Report() {}


	public Report(Integer reportId, Integer appointmentId, Date reportDate, Date time, byte[] reportImage, Date createdOn, String title) {
		super();
		this.reportId = reportId;
		this.appointmentId = appointmentId;
		this.reportDate = reportDate;
		this.time = time;
		this.reportImage = reportImage;
		this.createdOn = createdOn;
		this.title = title;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public Report(Integer appointmentId, Date reportDate, Date time, byte[] reportImage, Date createdOn, String title) {
		super();
		this.appointmentId = appointmentId;
		this.reportDate = reportDate;
		this.time = time;
		this.reportImage = reportImage;
		this.createdOn = createdOn;
		this.title = title;
	}


	public Integer getreportId() {
		return reportId;
	}

	public void setreportId(Integer reportId) {
		this.reportId = reportId;
	}

	public Integer getappointmentId() {
		return appointmentId;
	}

	public void setappointmentId(Integer appointmentId) {
		this.appointmentId = appointmentId;
	}

	public Date getreportDate() {
		return this.reportDate;
	}

	public void setreportDate(Date reportDate) {
		this.reportDate = reportDate;
	}

	public Date gettime() {
		return this.time;
	}

	public void settime(Date time) {
		this.time = time;
	}


	public byte[] getreportImage() {
		return this.reportImage;
	}

	public void setreportImage(byte[] reportImage) {
		this.reportImage = reportImage;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

//	public String getTime1() {
//		SimpleDateFormat sdf =new SimpleDateFormat("HH:mm");
//		return sdf.format(time);
//	}
	@Override

	public String toString() {
		String resp="";
		if(reportImage==null) {
			resp = "Image not available";
		}else {
			resp=reportImage.length +" KB";
		}
		return "Report("+reportId+") \n\t{\n\tReport Id -> " + reportId + 
				"\n\tAppointment Id -> " + appointmentId +  
				"\n\tReport Title -> " + title +  
				//"\n\tReport Date -> " + DateFormater.defaultDateFormat(reportDate) + 
			//	"\n\tTime -> " + getTime1() + 
				"\n\tReport Image -> " + resp + 
				//"\n\tCreated On -> "+  DateFormater.defaultDateFormat(createdOn) + 
				"\n\t}";
	}

	public Report(Integer reportId, Integer appointmentId, Date reportDate, Date time, byte[] reportImage) {
		super();
		this.reportId = reportId;
		this.appointmentId = appointmentId;
		this.reportDate = reportDate;
		this.time = time;
		this.reportImage = reportImage;
	}
}









