package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

//specId CHAR(6) PRIMARY KEY,
//specializationName VARCHAR2(30) NOT NULL
@Entity
public class Specialization {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer specId;
	private String specializationName;
	private String description;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Specialization() {
	}
	
	public Specialization(String specializationName) {
		super();
		
		this.specializationName = specializationName;
	}

	public Specialization(Integer specId, String specializationName) {
		super();
		this.specId = specId;
		this.specializationName = specializationName;
	}

	public Integer getSpecId() {
		return specId;
	}

	public void setSpecId(Integer specId) {
		this.specId = specId;
	}

	public String getSpecializationName() {
		return specializationName;
	}

	public void setSpecializationName(String specializationName) {
		this.specializationName = specializationName;
	}

	@Override
	public String toString() {
		return "Specialization("+specId+") \n\t{\n\tId ->" +specId+ 	
		", \n\tSpecialization Name -> " + specializationName + 
		"\n\t}";
	}
    
}
