package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Doctor;
// employee with role-
@Repository
public interface DoctorRepository extends JpaRepository<Doctor, Integer>{
	@Query("SELECT  e.firstName,e.lastName,d.experience,d.achievement,d.dId,d.empId FROM Doctor d JOIN Employee e ON d.empId=e.empId" + 
			" WHERE e.firstName like %:name% OR e.lastName like %:name% "
			)
	List<Object> findDoctorByName(@Param("name") String name);
//
	@Query("SELECT  e.firstName,e.lastName,d.experience,d.achievement,d.dId,d.empId FROM Doctor d JOIN Employee e ON d.empId=e.empId  WHERE d.dId in (SELECT ds.docId from DoctorSpecialization ds where ds.specId =(Select s.specId from Specialization s where s.specializationName like %:specialization%))") 
	List<Object> findDoctorBySpecialization(@Param("specialization") String specialization);

	@Query("SELECT e.firstName,e.lastName,d.experience,d.achievement,d.dId,d.empId FROM Doctor d JOIN Employee e ON d.empId=e.empId")
	List<Object> getDoctorWithAllDetails();
	
	@Query("SELECT d.dId FROM Doctor d JOIN Employee e ON d.empId=e.empId where e.email=:userName")
	Integer getDoctorId(@Param("userName")String userName);
}
