package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer>{
	@Query("SELECT e from Employee e where e.empId not in (SELECT d.empId from Doctor d) and e.profile=(SELECT p.profileId from Profile p where p.profileName='Doctor')")
	List<Employee> findUnmappedDoctors();
	@Query("SELECT e,p from Employee e Join Profile p ON e.profile=p.profileId")
	List<Object> findEmployeeWithProfile();
}
