package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Appointment;
import com.example.demo.entity.Prescription;

@Repository
public interface PrescriptionRepository extends JpaRepository<Prescription, Integer>{
	@Query("SELECT p  FROM Prescription p JOIN Appointment a ON p.appointmentId=a.appointmentId where a.patientId=:id")
    List<Object> getPrescriptionWithAppointmentDetails(@Param("id") Integer id);
}
