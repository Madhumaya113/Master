package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Report;

@Repository
public interface ReportRepository extends JpaRepository<Report, Integer>{
	@Query("SELECT r.reportId,r.appointmentId,r.reportDate,r.time,r.reportImage,r.title,a.appointmentDate,a.timeSlot  FROM Report r JOIN Appointment a ON r.appointmentId=a.appointmentId where a.patientId=:id")
    List<Object> getReportWithAppointmentDetails(@Param("id") Integer id);
}
