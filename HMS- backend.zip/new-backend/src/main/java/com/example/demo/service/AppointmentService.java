package com.example.demo.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.demo.entity.Appointment;
import com.example.demo.repository.AppointmentRepository;

@Component("appointmentService")
public class AppointmentService implements IAppointmentService {
	@Autowired
	private AppointmentRepository appointmentRepository;
	@Override
	public Appointment create(Appointment appointment) {
		return appointmentRepository.save(appointment);
	}
	//if id is not found???
	@Override
	public Appointment read(Integer id) {
		Appointment appointment=null;
		try {
			appointment=appointmentRepository.findById(id).get();
		}catch(Exception ee) {
			appointment=null;
		}
		return appointment;
	}

	@Override
	public List<Appointment> read() {
		return appointmentRepository.findAll();	
	}

	@Override
	public Appointment update(Appointment appointment) {
		return appointmentRepository.save(appointment);
	}

	@Override
	public void delete(Appointment appointment) {
		appointmentRepository.delete(appointment);
	}

	public List<Appointment> getUserAppointment(Integer id) {
		return appointmentRepository.findPatientAppointment(id);
	}
	
	public Integer rescheduleAppointment(Integer id,Date date, Date time) {
		return appointmentRepository.rescheduleAppointment(date, time, id);
	}
	
	public Integer cancelAppointment(Integer id) {
		return appointmentRepository.cancelAppointment(id);
	}
}
