package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Doctor;
import com.example.demo.repository.DoctorRepository;

@Component("doctorService")
public class DoctorService implements IDoctorService {
	@Autowired
	private DoctorRepository doctorRepository;
	@Override
	public Doctor create(Doctor doctor) {
		return doctorRepository.save(doctor);
	}
	//if id is not found???
	@Override
	public Doctor read(Integer id) {
		Doctor doctor=null;
		try {
			doctor=doctorRepository.findById(id).get();
		}catch(Exception ee) {
			doctor=null;
		}
		return doctor;
	}

	@Override
	public List<Doctor> read() {
		return doctorRepository.findAll();	
	}

	@Override
	public Doctor update(Doctor doctor) {
		return doctorRepository.save(doctor);
	}

	@Override
	public void delete(Doctor doctor) {
		doctorRepository.delete(doctor);
	}
	
	public List<Object> findDoctorByName(String name) {
		return doctorRepository.findDoctorByName(name);
	}
	
	public List<Object> findDoctorBySpecialization(String specialization) {
		return doctorRepository.findDoctorBySpecialization(specialization);
	}
	
	public List<Object> findDoctorWithDetails(){
		return doctorRepository.getDoctorWithAllDetails();
	}
	
	public Integer getDoctorId(String userName) {
		return doctorRepository.getDoctorId(userName);
	}
	
}
