package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.DoctorSpecialization;
import com.example.demo.repository.DoctorSpecializationRepository;

@Component("doctorSpecializationService")
public class DoctorSpecializationService implements IDoctorSpecializationService {
	@Autowired
	private DoctorSpecializationRepository doctorSpecializationRepository;
	@Override
	public DoctorSpecialization create(DoctorSpecialization doctorSpecialization) {
		return doctorSpecializationRepository.save(doctorSpecialization);
	}
	//if id is not found???
	@Override
	public DoctorSpecialization read(Integer id) {
		DoctorSpecialization doctorSpecialization=null;
		try {
			doctorSpecialization=doctorSpecializationRepository.findById(id).get();
		}catch(Exception ee) {
			doctorSpecialization=null;
		}
		return doctorSpecialization;
	}

	@Override
	public List<DoctorSpecialization> read() {
		return doctorSpecializationRepository.findAll();	
	}

	@Override
	public DoctorSpecialization update(DoctorSpecialization doctorSpecialization) {
		return doctorSpecializationRepository.save(doctorSpecialization);
	}

	@Override
	public void delete(DoctorSpecialization doctorSpecialization) {
		doctorSpecializationRepository.delete(doctorSpecialization);
	}
}
