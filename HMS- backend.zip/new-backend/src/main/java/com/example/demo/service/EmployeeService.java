package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepository;

@Component("employeeService")
public class EmployeeService implements IEmployeeService {
	@Autowired
	private EmployeeRepository employeeRepository;
	@Override
	public Employee create(Employee employee) {
		return employeeRepository.save(employee);
	}
	//if id is not found???
	@Override
	public Employee read(Integer id) {
		Employee employee=null;
		try {
			employee=employeeRepository.findById(id).get();
		}catch(Exception ee) {
			employee=null;
		}
		return employee;
	}

	@Override
	public List<Employee> read() {
		return employeeRepository.findAll();	
	}

	@Override
	public Employee update(Employee employee) {
		return employeeRepository.save(employee);
	}

	@Override
	public void delete(Employee employee) {
		employeeRepository.delete(employee);
	}
	
	public List<Employee> getUnmappedDoctors() {
		return employeeRepository.findUnmappedDoctors();
	}
}
