package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Appointment;

public interface IAppointmentService {

	Appointment create(Appointment appointment);

	//if id is not found???
	Appointment read(Integer id);

	List<Appointment> read();

	Appointment update(Appointment appointment);

	void delete(Appointment appointment);

}