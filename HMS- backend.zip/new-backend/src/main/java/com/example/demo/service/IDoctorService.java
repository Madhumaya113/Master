package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Doctor;

public interface IDoctorService {

	Doctor create(Doctor doctor);

	//if id is not found???
	Doctor read(Integer id);

	List<Doctor> read();

	Doctor update(Doctor doctor);

	void delete(Doctor doctor);

}