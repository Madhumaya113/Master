package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.DoctorSpecialization;

public interface IDoctorSpecializationService {

	DoctorSpecialization create(DoctorSpecialization doctorSpecialization);

	//if id is not found???
	DoctorSpecialization read(Integer id);

	List<DoctorSpecialization> read();

	DoctorSpecialization update(DoctorSpecialization doctorSpecialization);

	void delete(DoctorSpecialization doctorSpecialization);

}