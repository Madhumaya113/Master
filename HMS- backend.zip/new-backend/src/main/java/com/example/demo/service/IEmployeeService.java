package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Employee;

public interface IEmployeeService {

	Employee create(Employee employee);

	//if id is not found???
	Employee read(Integer id);

	List<Employee> read();

	Employee update(Employee employee);

	void delete(Employee employee);

}