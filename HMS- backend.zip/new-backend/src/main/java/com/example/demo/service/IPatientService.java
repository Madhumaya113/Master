package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Patient;

public interface IPatientService {

	Patient create(Patient patient);

	//if id is not found???
	Patient read(Integer id);

	List<Patient> read();

	Patient update(Patient patient);

	void delete(Patient patient);

}