package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Payment;

public interface IPaymentService {

	Payment create(Payment payment);

	//if id is not found???
	Payment read(Integer id);

	List<Payment> read();

	Payment update(Payment payment);

	void delete(Payment payment);

}