package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Prescription;

public interface IPrescriptionService {

	Prescription create(Prescription prescription);

	//if id is not found???
	Prescription read(Integer id);

	List<Prescription> read();

	Prescription update(Prescription prescription);

	void delete(Prescription prescription);

}