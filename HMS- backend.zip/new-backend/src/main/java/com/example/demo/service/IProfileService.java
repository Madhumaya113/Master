package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Profile;

public interface IProfileService {

	Profile create(Profile profile);

	//if id is not found???
	Profile read(Integer id);

	List<Profile> read();

	Profile update(Profile profile);

	void delete(Profile profile);

}