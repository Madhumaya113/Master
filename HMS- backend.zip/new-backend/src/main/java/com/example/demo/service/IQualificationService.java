package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Qualification;

public interface IQualificationService {

	Qualification create(Qualification qualification);

	//if id is not found???
	Qualification read(Integer id);

	List<Qualification> read();

	Qualification update(Qualification qualification);

	void delete(Qualification qualification);

}