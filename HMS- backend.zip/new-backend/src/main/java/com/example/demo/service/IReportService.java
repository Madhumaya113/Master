package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Report;

public interface IReportService {

	Report create(Report report);

	//if id is not found???
	Report read(Integer id);

	List<Report> read();

	Report update(Report report);

	void delete(Report report);

}