package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Specialization;

public interface ISpecializationService {

	Specialization create(Specialization specialization);

	//if id is not found???
	Specialization read(Integer id);

	List<Specialization> read();

	Specialization update(Specialization specialization);

	void delete(Specialization specialization);

}