package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.User;

public interface IUserService {

	User create(User user);

	//if id is not found???
	User read(Integer id);

	List<User> read();

	User update(User user);

	void delete(User user);

}