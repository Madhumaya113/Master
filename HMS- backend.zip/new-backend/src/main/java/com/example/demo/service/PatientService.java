package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Patient;
import com.example.demo.repository.PatientRepository;

@Component("patientService")
public class PatientService implements IPatientService {
	@Autowired
	private PatientRepository patientRepository;
	@Override
	public Patient create(Patient patient) {
		return patientRepository.save(patient);
	}
	//if id is not found???
	@Override
	public Patient read(Integer id) {
		Patient patient=null;
		try {
			patient=patientRepository.findById(id).get();
		}catch(Exception ee) {
			patient=null;
		}
		return patient;
	}

	@Override
	public List<Patient> read() {
		return patientRepository.findAll();	
	}

	@Override
	public Patient update(Patient patient) {
		return patientRepository.save(patient);
	}

	@Override
	public void delete(Patient patient) {
		patientRepository.delete(patient);
	}
	
	public Integer getPatientId(String userName) {
		return patientRepository.getPatientId(userName);
	}
}
