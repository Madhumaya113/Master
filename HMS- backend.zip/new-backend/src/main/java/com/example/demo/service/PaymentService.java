package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Payment;
import com.example.demo.repository.PaymentRepository;

@Component("paymentService")
public class PaymentService implements IPaymentService {
	@Autowired
	private PaymentRepository paymentRepository;
	@Override
	public Payment create(Payment payment) {
		return paymentRepository.save(payment);
	}
	//if id is not found???
	@Override
	public Payment read(Integer id) {
		Payment payment=null;
		try {
			payment=paymentRepository.findById(id).get();
		}catch(Exception ee) {
			payment=null;
		}
		return payment;
	}

	@Override
	public List<Payment> read() {
		return paymentRepository.findAll();	
	}

	@Override
	public Payment update(Payment payment) {
		return paymentRepository.save(payment);
	}

	@Override
	public void delete(Payment payment) {
		paymentRepository.delete(payment);
	}
}
