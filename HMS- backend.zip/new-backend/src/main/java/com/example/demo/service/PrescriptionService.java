package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Prescription;
import com.example.demo.repository.PrescriptionRepository;

@Component("prescriptionService")
public class PrescriptionService implements IPrescriptionService  {
	@Autowired
	private PrescriptionRepository prescriptionRepository;
	@Override
	public Prescription create(Prescription prescription) {
		return prescriptionRepository.save(prescription);
	}
	//if id is not found???
	@Override
	public Prescription read(Integer id) {
		Prescription prescription=null;
		try {
			prescription=prescriptionRepository.findById(id).get();
		}catch(Exception ee) {
			prescription=null;
		}
		return prescription;
	}

	@Override
	public List<Prescription> read() {
		return prescriptionRepository.findAll();	
	}

	@Override
	public Prescription update(Prescription prescription) {
		return prescriptionRepository.save(prescription);
	}

	@Override
	public void delete(Prescription prescription) {
		prescriptionRepository.delete(prescription);
	}
	public  List<Object> getPrescriptionWithDetails(Integer id) {
        return prescriptionRepository.getPrescriptionWithAppointmentDetails(id);
	}
}
