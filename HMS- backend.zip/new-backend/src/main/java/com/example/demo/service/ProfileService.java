package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Profile;
import com.example.demo.repository.ProfileRepository;

@Component("profileService")
public class ProfileService implements IProfileService {
	@Autowired
	private ProfileRepository profileRepository;
	@Override
	public Profile create(Profile profile) {
		return profileRepository.save(profile);
	}
	//if id is not found???
	@Override
	public Profile read(Integer id) {
		Profile profile=null;
		try {
			profile=profileRepository.findById(id).get();
		}catch(Exception ee) {
			profile=null;
		}
		return profile;
	}

	@Override
	public List<Profile> read() {
		return profileRepository.findAll();	
	}

	@Override
	public Profile update(Profile profile) {
		return profileRepository.save(profile);
	}

	@Override
	public void delete(Profile profile) {
		profileRepository.delete(profile);
	}
}
