package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Qualification;
import com.example.demo.repository.QualificationRepository;

@Component("qualificationService")
public class QualificationService implements IQualificationService {
	@Autowired
	private QualificationRepository qualificationRepository;
	@Override
	public Qualification create(Qualification qualification) {
		return qualificationRepository.save(qualification);
	}
	//if id is not found???
	@Override
	public Qualification read(Integer id) {
		Qualification qualification=null;
		try {
			qualification=qualificationRepository.findById(id).get();
		}catch(Exception ee) {
			qualification=null;
		}
		return qualification;
	}

	@Override
	public List<Qualification> read() {
		return qualificationRepository.findAll();	
	}

	@Override
	public Qualification update(Qualification qualification) {
		return qualificationRepository.save(qualification);
	}

	@Override
	public void delete(Qualification qualification) {
		qualificationRepository.delete(qualification);
	}
	public List<Qualification> getEmployeeQualification(Integer empId) {
		return qualificationRepository.getQualificationByEmployeeId(empId);
	}
}
