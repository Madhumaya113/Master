package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Report;
import com.example.demo.repository.ReportRepository;

@Component("reportService")
public class ReportService implements IReportService {
	@Autowired
	private ReportRepository reportRepository;
	@Override
	public Report create(Report report) {
		return reportRepository.save(report);
	}
	//if id is not found???
	@Override
	public Report read(Integer id) {
		Report report=null;
		try {
			report=reportRepository.findById(id).get();
		}catch(Exception ee) {
			report=null;
		}
		return report;
	}

	@Override
	public List<Report> read() {
		return reportRepository.findAll();	
	}

	@Override
	public Report update(Report report) {
		return reportRepository.save(report);
	}

	@Override
	public void delete(Report report) {
		reportRepository.delete(report);
	}
	
	public List<Object> getReportWithDetails(Integer id) {
        return reportRepository.getReportWithAppointmentDetails(id);
	}
}
