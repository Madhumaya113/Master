package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Specialization;
import com.example.demo.repository.SpecializationRepository;

@Component("specializationService")
public class SpecializationService implements ISpecializationService {
	@Autowired
	private SpecializationRepository specializationRepository;
	@Override
	public Specialization create(Specialization specialization) {
		return specializationRepository.save(specialization);
	}
	//if id is not found???
	@Override
	public Specialization read(Integer id) {
		Specialization specialization=null;
		try {
			specialization=specializationRepository.findById(id).get();
		}catch(Exception ee) {
			specialization=null;
		}
		return specialization;
	}

	@Override
	public List<Specialization> read() {
		return specializationRepository.findAll();	
	}

	@Override
	public Specialization update(Specialization specialization) {
		return specializationRepository.save(specialization);
	}

	@Override
	public void delete(Specialization specialization) {
		specializationRepository.delete(specialization);
	}
}
