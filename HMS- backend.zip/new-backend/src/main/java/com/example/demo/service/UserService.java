package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;

@Component("userService")
public class UserService implements IUserService {
	@Autowired
	private UserRepository userRepository;
	@Override
	public User create(User user) {
		User res;
		try {
		res= userRepository.save(user);
		}catch(Exception ee) {
			res=null;
		}
		return res;
	}

	@Override
	public User read(Integer id) {
		User user=null;
		try {
			user=userRepository.findById(id).get();
		}catch(Exception ee) {
			user=null;
		}
		return user;
	}

	@Override
	public List<User> read() {
		return userRepository.findAll();	
	}

	@Override
	public User update(User user) {
		return userRepository.save(user);
	}

	@Override
	public void delete(User user) {
		userRepository.delete(user);
	}
	
	public User getUserByUsername(String userName) {
		User user=null;
		try {
		 user =userRepository.findUserByEmail(userName).get(0);
		}catch(Exception ee) {
			user=null;
		}
		return user;
	}
	
	
	public int updatePassword(String password , String email) {
		return userRepository.updatePassword(password, email);
	}

}
