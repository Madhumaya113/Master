import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { EmployeeService } from 'src/app/services/employee.service';
import { SpecializationService } from 'src/app/services/specialization.service';
import { PhysicianService } from '../../../services/physician.service';

@Component({
  selector: 'doctor-form',
  templateUrl: './doctor-form.component.html',
  styleUrls: ['./doctor-form.component.css']
})
export class DoctorFormComponent implements OnInit {
  doctorForm: any;
  isEdit: boolean = false;
  @Input() doctor: any;
  @Input() isEditable: boolean = true;
  specializationList:any;
  unmappedEmployeeList:any;
  constructor(private formBuilder: FormBuilder, private service: PhysicianService,
    private specService:SpecializationService, private empService:EmployeeService) {
    this.doctorForm = this.formBuilder.group({
      dId: [''],
      empId: ['', [Validators.required]],
      experience: ['', [Validators.required]],
      achievement: ['', [Validators.required]],
      specialization: ['', [Validators.required]]
    });
  }
  ngOnChanges(changes: SimpleChanges): void {
    if (!this.isEditable) {
      this.doctorForm.disable();
    }
    else {
      this.doctorForm.enable();
    }
    if (this.doctor != undefined) {
      this.doctorForm.patchValue(this.doctor);
      this.doctorForm.markAsUntouched();
      console.log(this.doctor)
    } else {
      this.doctorForm.reset();
    }
  }

  ngOnInit(): void {
    this.specService.getSpecializationList().subscribe(data=>{this.specializationList=data})
    this.empService.getUnmappedEmployee().subscribe(data=>{this.unmappedEmployeeList=data;console.log(data)})
  }
  get formControl() {
    return this.doctorForm.controls;
  }
  fnSaveDoctor() {
    if (this.doctor != undefined && this.doctor.empId != null) {
      this.service.updateDoctor(this.doctorForm.value).subscribe(data => { console.log(JSON.stringify(data));window.location.reload() })
      return;
    }
    this.service.addDoctor(this.doctorForm.value).subscribe(data => { console.log(JSON.stringify(data));window.location.reload() })
  }
}
