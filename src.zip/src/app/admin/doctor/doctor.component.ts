import { Component, OnInit } from '@angular/core';
import { SpecializationService } from 'src/app/services/specialization.service';
import { PhysicianService } from '../../services/physician.service';

@Component({
  selector: 'app-doctor',
  templateUrl: './doctor.component.html',
  styleUrls: ['./doctor.component.css']
})
export class DoctorComponent implements OnInit {
  doctor:any;
  doctorList:any;
  doctorName:any;
  specializationList:any;
  isEditable:boolean=true;
  constructor(private service:PhysicianService) { }
  ngOnInit(): void {
    this.service. getAllPhysician().subscribe(data=>{this.doctorList=data;console.log(data)});
   
    // this.service.getDoctorName(1010).subscribe(data=>this.doctorName=data)
  }
  editDoctor(doctor:any){
    this.doctor=doctor;
    this.isEditable=true;
  }
  addDoctor(){
    this.isEditable=true;
    this.doctor=undefined;
  }
  viewDoctor(doctor:any){
    this.doctor=doctor;
    this.isEditable=false;
  }
  fnDelete(){
    
  }
}
