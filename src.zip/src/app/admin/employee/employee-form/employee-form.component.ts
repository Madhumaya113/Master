import { Component, ElementRef, Input, OnChanges, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { EmployeeService } from 'src/app/services/employee.service';
import { PatientService } from 'src/app/services/patient.service';
import { ProfileService } from 'src/app/services/profile.service';

@Component({
  selector: 'employee-form',
  templateUrl: './employee-form.component.html',
  styleUrls: ['./employee-form.component.css']
})
export class EmployeeFormComponent implements OnInit, OnChanges {
  employeeForm: any;
  profileList:any;
  isEdit: boolean = false;
  pageTitle: string = "PHYSICIAN SIGN UP";
  @Input() employee: any;
  @Input() isEditable: boolean = true;
  btnText: string = "Sign up";
  date: Date = new Date(Date.now());
  selectedProfile:any;
  today = "";
  constructor(private formBuilder: FormBuilder, private service: EmployeeService, private pservice:ProfileService) {
    this.employeeForm = this.formBuilder.group({
      empId: [''],
      firstName: ['', [Validators.required, Validators.minLength(3)]],
      lastName: ['', [Validators.required]],
      gender: ['', [Validators.required]],
      dateofbirth: ['', [Validators.required]],
      // Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]
      email: ['', [Validators.required]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', [Validators.required]],
      contactNo: ['', [Validators.required, Validators.pattern("^[0-9]*$"), Validators.minLength(10), Validators.maxLength(10)]],
      altContact: ['', [Validators.pattern("^[0-9]*$"), Validators.minLength(10), Validators.maxLength(10)]],
      address: ['', [Validators.required]],
      profile:[null,[Validators.required]]
    }
      // 
      // {
      //   validator: [MustMatch('password','confirmPassword'),dateExpected(true,'dateofbirth')]
      // }
    )
  }
  ngOnChanges(changes: SimpleChanges): void {
    if (!this.isEditable) {
      this.employeeForm.disable();
    }
    else {
      this.employeeForm.enable();
    }
    if (this.employee != undefined) {
      this.employeeForm.patchValue(this.employee);
      this.employeeForm.markAsUntouched();
      // this.employeeForm.markAsPristine()
      console.log(this.employee)
    } else {
      this.employeeForm.reset();
    }
  }

  ngOnInit(): void {
    this.today = this.date.getFullYear() + "-" + (this.date.getMonth() + 1) + "-" + this.date.getDate();
    this.pservice.getProfileList().subscribe(data=>this.profileList=data);
  }
  get formControl() {
    return this.employeeForm.controls;
  }
  fnSaveEmployee() {
    console.log(this.employeeForm.value)
    if (this.employee != undefined && this.employee.empId != null) {
      this.service.updateEmployee(this.employeeForm.value).subscribe(data => { console.log(JSON.stringify(data));window.location.reload() })
      return;
    }
    this.service.addEmployee(this.employeeForm.value).subscribe(data => { console.log(JSON.stringify(data));;window.location.reload() })
  }

  fnGetProfile(){
    let data=this.employeeForm.value;
    this.service.getEmployee(data).subscribe(data=>{this.selectedProfile=data});
  }
}
