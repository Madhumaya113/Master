import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from 'src/app/services/employee.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  employee:any;
  employeeList:any;
  isEditable:boolean=true;
  constructor(private service:EmployeeService,private router:Router) { }
  
  ngOnInit(): void {
    this.service.getEmployeeList().subscribe(data=>this.employeeList=data)
  }
  editEmployee(employee:any){
    this.employee=employee;
    this.isEditable=true;
  }
  addEmployee(){
    this.isEditable=true;
    this.employee=undefined;
  }
  viewEmployee(employee:any){
    this.employee=employee;
    this.isEditable=false;
  }
  deleteEmployee(emp:any){
    console.log(emp);
    this.service.deleteEmployee(emp).subscribe(data=>{
      this.ngOnInit()
      })
  
  }
}
