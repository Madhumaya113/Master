import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ProfileService } from 'src/app/services/profile.service';

@Component({
  selector: 'profile-form',
  templateUrl: './profile-form.component.html',
  styleUrls: ['./profile-form.component.css']
})
export class ProfileFormComponent implements OnInit {
  profileForm: any;
  isEdit: boolean = false;
  @Input() profile: any;
  @Input() isEditable: boolean = true;
  constructor(private formBuilder: FormBuilder, private service: ProfileService) {
    this.profileForm = this.formBuilder.group({
      profileId: [''],
      profileName: ['', [Validators.required, Validators.minLength(3)]]
    });
  }
  ngOnChanges(changes: SimpleChanges): void {
    if (!this.isEditable) {
      this.profileForm.disable();
    }
    else {
      this.profileForm.enable();
    }
    if (this.profile != undefined) {
      this.profileForm.patchValue(this.profile);
      this.profileForm.markAsUntouched();
      console.log(this.profile)
    } else {
      this.profileForm.reset();
    }
  }

  ngOnInit(): void {
  }
  get formControl() {
    return this.profileForm.controls;
  }
  fnSaveProfile() {
    if(this.profileForm.valid){
    if (this.profile != undefined && this.profile.empId != null) {
      this.service.updateProfile(this.profileForm.value).subscribe(data => { console.log(JSON.stringify(data));window.location.reload() })
      return;
    }
    this.service.addProfile(this.profileForm.value).subscribe(data => { console.log(JSON.stringify(data));window.location.reload() })
    }else {
      alert("all fields are mandatory");
    }
  } 
}
