import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProfileService } from 'src/app/services/profile.service';

@Component({
  selector: 'profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  profile:any;
  profileList:any;
  isEditable:boolean=true;
  constructor(private service:ProfileService,private router:Router) { }
  ngOnInit(): void {
    this.service.getProfileList().subscribe(data=>this.profileList=data)
  }
  editProfile(profile:any){
    this.profile=profile;
    this.isEditable=true;
  }
  addProfile(){
    this.isEditable=true;
    this.profile=undefined;
  }
  viewProfile(profile:any){
    this.profile=profile;
    this.isEditable=false;
  }
  fnDelete(id:number){
    alert(id);
    this.service.deleteProfile(id).subscribe(data=>{console.log(data)
    this.router.navigateByUrl("/employee/profile")});
  }
}
