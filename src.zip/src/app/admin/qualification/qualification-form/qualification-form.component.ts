import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { QualificationService } from 'src/app/services/qualification.service';

@Component({
  selector: 'qualification-form',
  templateUrl: './qualification-form.component.html',
  styleUrls: ['./qualification-form.component.css']
})
export class QualificationFormComponent implements OnInit,OnChanges {
  QualificationForm: any;
  Qualification: any;
  // isEditable: boolean = false;
  pageTitle: string = "Qualification Form";
  @Input() qualification: any;
  @Input() isEditable: boolean = true;
  @Input() employeeId:any;
  date: Date = new Date(Date.now());
  today = "";
  constructor(private formBuilder: FormBuilder, private service: QualificationService,private router:Router) {
   
    this.QualificationForm = this.formBuilder.group({
      qualId: [''],
      qualification: ['', [Validators.required, Validators.minLength(3)]],
      instituteName: ['', [Validators.required]],
      procurementYear: ['', [Validators.required]]
    });
  }
  ngOnChanges(changes: SimpleChanges): void {
    if (!this.isEditable) {
      this.QualificationForm.disable();
    }
    else {
      this.QualificationForm.enable();
    }
    if (this.qualification != undefined) {
      this.QualificationForm.patchValue(this.qualification);
      this.QualificationForm.markAsUntouched();
      console.log(this.qualification)
    } else {
      this.QualificationForm.reset();
    }
  }
  ngOnInit(): void {
    this.today = this.date.getFullYear() + "-" + (this.date.getMonth() + 1) + "-" + this.date.getDate();
  }
  get formControl() {
    return this.QualificationForm.controls;
  }
  fnSaveQualification() {
    console.log(this.employeeId+"-----------")
    console.log(this.QualificationForm.value);
    if (this.qualification != undefined && this.qualification.qualId != null) {
      this.service.updateQualification(this.employeeId,this.QualificationForm.value).subscribe(data => {
         console.log(JSON.stringify(data)); 
        this.ngOnInit();
        })
      return;
    }
    this.service.addQualification(this.employeeId,this.QualificationForm.value).subscribe(data => { console.log(JSON.stringify(data))
      this.ngOnInit();
    })
  }
}
