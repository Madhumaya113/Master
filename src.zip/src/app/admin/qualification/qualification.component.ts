import { Component, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { EmployeeService } from 'src/app/services/employee.service';
import { QualificationService } from 'src/app/services/qualification.service';

@Component({
  selector: 'app-qualification',
  templateUrl: './qualification.component.html',
  styleUrls: ['./qualification.component.css']
})
export class QualificationComponent implements OnInit {
  employeeDetails:any;
  qualification:any;
  employeeId:any=undefined;
  qualificationList:any;
  isEditable:boolean=true;
  constructor(private qualService:QualificationService,private empService:EmployeeService,private route:ActivatedRoute) {
  }
  ngOnInit(): void {
    this.route.queryParams.subscribe(params=>{
      this.employeeId=params.employee
      this.empService.getEmployee(this.employeeId).subscribe(data=>{
        this.employeeDetails=data;
        console.log(data);
        this.qualService.getQualifications(this.employeeId).subscribe(data=>{this.qualificationList=data;console.log(data)})
      })
    })
  }
  addQualification()
  {
    // alert(this.employeeId);
    this.isEditable=true;
    this.employeeId=this.employeeId;
    this.qualification=undefined;
  }
  viewQualification(qualification:any)
  {
    this.employeeId=this.employeeId;
    this.qualification=qualification;
    this.isEditable=false;
  }
  editQualification(qualification:any)
  {
    this.employeeId=this.employeeId;
    this.qualification=qualification;
    this.isEditable=true;
  }
  deleteQualification(id:any)
  {
   this.qualService.deleteQualification(id).subscribe(data=>
    this.ngOnInit());
  }

}
