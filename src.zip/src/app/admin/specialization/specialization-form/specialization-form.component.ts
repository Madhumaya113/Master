import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { SpecializationService } from 'src/app/services/specialization.service';

@Component({
  selector: 'specialization-form',
  templateUrl: './specialization-form.component.html',
  styleUrls: ['./specialization-form.component.css']
})
export class SpecializationFormComponent implements OnInit {

  specializationForm: any;
  isEdit: boolean = false;
  @Input() specialization: any;
  @Input() isEditable: boolean = true;
  // date: Date = new Date(Date.now());
  today = "";
  constructor(private formBuilder: FormBuilder, private service: SpecializationService) {
    this.specializationForm = this.formBuilder.group({
      specId: [''],
      specializationName: ['', [Validators.required, Validators.minLength(3)]],
      description: ['', [Validators.required, Validators.minLength(10)]]
    });
  }
  ngOnChanges(changes: SimpleChanges): void {
    if (!this.isEditable) {
      this.specializationForm.disable();
    }
    else {
      this.specializationForm.enable();
    }
    if (this.specialization != undefined) {
      this.specializationForm.patchValue(this.specialization);
      this.specializationForm.markAsUntouched();
      // this.employeeForm.markAsPristine()
      console.log(this.specialization)
    } else {
      this.specializationForm.reset();
    }
  }

  ngOnInit(): void {
    // this.today = this.date.getFullYear() + "-" + (this.date.getMonth() + 1) + "-" + this.date.getDate();
  }
  get formControl() {
    return this.specializationForm.controls;
  }
  fnSaveSpecialization() {
    if (this.specializationForm.valid) {
      if (this.specialization != undefined && this.specialization.empId != null) {
        this.service.updateSpecialization(this.specializationForm.value).subscribe(data => { console.log(JSON.stringify(data)); window.location.reload() })
        return;
      }
      this.service.addSpecialization(this.specializationForm.value).subscribe(data => { console.log(JSON.stringify(data)); window.location.reload() })
    } else {
      alert("All fields are mendatory")
    }
  }
}

