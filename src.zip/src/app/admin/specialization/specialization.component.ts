import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SpecializationService } from 'src/app/services/specialization.service';

@Component({
  selector: 'app-specialization',
  templateUrl: './specialization.component.html',
  styleUrls: ['./specialization.component.css']
})
export class SpecializationComponent implements OnInit {
  specialization: any;
  specializationList: any;
  isEditable: boolean = true;
  constructor(private service: SpecializationService,private router:Router) { }
  ngOnInit(): void {
    this.service.getSpecializationList().subscribe(data => this.specializationList = data)
  }
  editSpecialization(specialization: any) {
    this.specialization = specialization;
    this.isEditable = true;
  }
  addSpecialization() {
    this.isEditable = true;
    this.specialization = undefined;
  }
  viewSpecialization(specialization: any) {
    this.specialization = specialization;
    this.isEditable = false;

  }
  fnDelete(specialization: any) {
    this.service.deleteSpecialization(specialization).subscribe(data=>{console.log(data);
      this.router.navigateByUrl("/employee/specialization")
    });
  }
}
