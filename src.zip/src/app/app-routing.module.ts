import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { StaffLoginComponent } from './hospital-staff/staff-login.component';
import {HomeComponent as AdminHome} from './admin/home/home.component';
import { PatientLoginComponent, PatientProfileComponent, PatientSignupComponent,
   PatientDiagnosisComponent, PatientReportComponent,PatientAppointments } from './patient';
import {  PhysicianComponent,PhysicianAppointments } from './physician';
import { AboutUsComponent } from './about-us/about-us.component';
import { ErrorComponent } from './common/error/error.component';
import { LoginComponent } from './login/login.component';
import {EmployeeComponent} from './admin/employee/employee.component';
import {QualificationComponent} from './admin/qualification/qualification.component';
import { SpecializationComponent } from './admin/specialization/specialization.component';
import { ProfileComponent } from './admin/profile/profile.component'
import {PrescriptionComponent} from './prescription/prescription.component';
import { AdminGuard } from './guard/admin.guard';
import {ResetPasswordComponent} from '../app/login/reset-password/reset-password.component';
import { PatientGuard } from './guard/patient.guard';
import {DoctorComponent} from './admin/doctor/doctor.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  // { path:'',},
  { path: 'login', component: LoginComponent },
  // { path: 'physician-signup', component: PhysicianSignupComponent },
  { path: 'patient-signup', component: PatientSignupComponent },
  { path: 'patient-profile', component: PatientProfileComponent },
  // ,canActivate:[AdminGuard]
  {path:'employee',component:EmployeeComponent},
  {path:'employee/qualification',component:QualificationComponent,canActivate:[AdminGuard]},
  // { path: 'physician-login', component: PhysicianLoginComponent },
  // { path: 'physician-profile', component: PhysicianProfileComponent },
  // { path: 'admin-login', component: AdminLoginComponent },
  // { path: 'staff-login', component: StaffLoginComponent },
  { path: 'about-us', component: AboutUsComponent },
  { path: 'doctor-list', component: PhysicianComponent },
  // { path: 'my-diagnosis', component: PatientDiagnosisComponent },
  {path: 'my-reports', component: PatientReportComponent},
  {path: 'my-appointment', component: PatientAppointments},
  {path:'physician-appointments',component:PhysicianAppointments},
  {path:'specialization', component:SpecializationComponent},
  {path:'profile', component:ProfileComponent},
  {path:'my-prescriptions',component:PrescriptionComponent},
  {path:'reset-password',component:ResetPasswordComponent},
  {path:'employee/doctor',component:DoctorComponent},
  {path:'admin-home',component:AdminHome},
  {path: '**', component: ErrorComponent },
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
