import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import {
  NavbarLeftComponent,
  NavbarRightComponent,
  NavigationBarComponent
} from './navigation-bar';

import {
  PatientComponent,
  PatientLoginComponent,
  PatientSignupComponent,
  PatientProfileComponent,
  PatientReportComponent,
  PatientDiagnosisComponent,
  PatientAppointments
} from './patient';

import {
  PhysicianComponent,
  PhysicianAppointments
} from './physician';


import { StaffLoginComponent } from './hospital-staff/staff-login.component';
import { HomeComponent } from './home/home.component';
import { AboutUsComponent } from './about-us/about-us.component';
import {
  ErrorComponent,
  EmptyComponent,
  CarouselComponent,
  PaymentComponent,
  appointmentsComponent,
  Modal,
  CardGroup
} from './common';
import { FixAppointmentComponent } from './common/fix-appointment/fix-appointment.component';
import { DoctorSerachFormComponent } from './common/doctor-serach-form/doctor-serach-form.component';
import { LoginComponent } from './login/login.component';
import { EmployeeComponent } from './admin/employee/employee.component';
import { EmployeeFormComponent } from './admin/employee/employee-form/employee-form.component';
import { QualificationComponent } from './admin/qualification/qualification.component';
import { QualificationFormComponent } from './admin/qualification/qualification-form/qualification-form.component';
import { SpecializationComponent } from './admin/specialization/specialization.component';
import { SpecializationFormComponent } from './admin/specialization/specialization-form/specialization-form.component';
import { ProfileComponent } from './admin/profile/profile.component';
import { ProfileFormComponent } from './admin/profile/profile-form/profile-form.component';
import { MyDatePipe } from './pipes/my-date.pipe';
import { ContactPipe } from './pipes/contact.pipe';
import { PrescriptionComponent } from './prescription/prescription.component';
import { ResetPasswordComponent } from './login/reset-password/reset-password.component';
import { DoctorComponent } from './admin/doctor/doctor.component';
import { DoctorFormComponent } from './admin/doctor/doctor-form/doctor-form.component';


@NgModule({
  declarations: [
    AppComponent,
    NavigationBarComponent,
    NavbarLeftComponent,
    NavbarRightComponent,
    PatientComponent,
    PatientLoginComponent,
    PatientSignupComponent,
    PhysicianComponent,
    CarouselComponent,
    // PhysicianSignupComponent,
    
    StaffLoginComponent,
    // PhysicianLoginComponent,
    PatientProfileComponent,
    // PhysicianProfileComponent,
    PaymentComponent,
    HomeComponent,
    AboutUsComponent,
    PatientReportComponent,
    PatientDiagnosisComponent,
    ErrorComponent,
    PatientAppointments,
    EmptyComponent,
    appointmentsComponent,
    PhysicianAppointments,
    CardGroup,
    Modal,
    FixAppointmentComponent,
    DoctorSerachFormComponent,
    LoginComponent,
    EmployeeComponent,
    EmployeeFormComponent,
    QualificationComponent,
    QualificationFormComponent,
    SpecializationComponent,
    SpecializationFormComponent,
    ProfileComponent,
    ProfileFormComponent,
    MyDatePipe,
    ContactPipe,
    PrescriptionComponent,
    ResetPasswordComponent,
    DoctorComponent,
    DoctorFormComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
