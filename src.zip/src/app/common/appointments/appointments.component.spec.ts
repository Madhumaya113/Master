import { ComponentFixture, TestBed } from '@angular/core/testing';

import { appointmentsComponent } from './appointments.component';

describe('appointmentsComponent', () => {
  let component: appointmentsComponent;
  let fixture: ComponentFixture<appointmentsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ appointmentsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(appointmentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
