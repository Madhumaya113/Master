import { Route } from '@angular/compiler/src/core';
import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AppointmentService } from 'src/app/services/appointment.service';

@Component({
  selector: 'appointment-list',
  templateUrl: './appointments.component.html',
  styleUrls: ['./appointments.component.css']
})
export class appointmentsComponent implements OnInit {
  appointmentForm:any;
  isPhysician=false;
  @Input() appointmentList: any;
  @Input()viewer:string='none'
  constructor(private service:AppointmentService,private router:Router,private fb: FormBuilder) {
    this.appointmentForm=this.fb.group({
      appointmentId:['',Validators.required],
      appointmentDate:['',Validators.required],
      timeSlot:['',Validators.required]
    })
  }
  get formControl() {
    return this.appointmentForm.controls;
  }
  ngOnInit(): void {
    // switch(this.viewer){
    //   case "Physician":this.isPhysician=true;break;
    // } 
  }
  fnCancelAppointment(id :number){
      this.service.cancelAppointment(id).subscribe(data=>{
        this.router.navigateByUrl("/my-appointment");
      });
  }
  fnRes(){
   
  }
}
