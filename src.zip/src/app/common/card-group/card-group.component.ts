import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-card-group',
  templateUrl: './card-group.component.html',
  styleUrls: ['./card-group.component.css']
})
export class CardGroupComponent implements OnInit {

  @Input() cards:any;
  constructor() { }

  ngOnInit(): void {
  }

}
