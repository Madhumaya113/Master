import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.css']
})
export class CarouselComponent implements OnInit {
  @Input() myImages = [
    { url: './assets/1.jpeg', text: 'my image' },
    { url: './assets/2.jpeg', text: 'image 1' },
    { url: './assets/3.jpg', text: 'image 2' },
    { url: './assets/4.jpg', text: 'image 3' }
  ];

  totalImages=this.myImages.length;


  constructor() { }

  ngOnInit(): void {
  }

}
