import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoctorSerachFormComponent } from './doctor-serach-form.component';

describe('DoctorSerachFormComponent', () => {
  let component: DoctorSerachFormComponent;
  let fixture: ComponentFixture<DoctorSerachFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DoctorSerachFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DoctorSerachFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
