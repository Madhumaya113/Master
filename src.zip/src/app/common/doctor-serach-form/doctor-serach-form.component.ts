import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-doctor-serach-form',
  templateUrl: './doctor-serach-form.component.html',
  styleUrls: ['./doctor-serach-form.component.css']
})
export class DoctorSerachFormComponent implements OnInit {
  SearchForm:any;
 // sname:any;
  constructor(private _activatedRoute: ActivatedRoute,
              private _router: Router, private fb:FormBuilder ) { 
                this.SearchForm=this.fb.group({ 
                  dname:['',[Validators.required]],
                  sname:['',[Validators.required]]
                });
              }

  ngOnInit(): void {
  }
  search(): void{
    
    var sname=this.SearchForm.controls.sname.value;
    var dname=this.SearchForm.controls.dname.value;
   
    if(dname!='' )
       {
        this._router.navigate(['/doctor-list'],{ queryParams: { name: dname }}); 
     
       } 
    if(sname!='' )
       {
        this._router.navigate(['/doctor-list'],{ queryParams: { spec: sname }}); 
   
       }    
  }
  
}

