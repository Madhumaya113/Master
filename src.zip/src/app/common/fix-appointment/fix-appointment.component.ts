import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AppointmentService } from 'src/app/services/appointment.service';
import { PhysicianService } from 'src/app/services/physician.service';

@Component({
  selector: 'app-fix-appointment',
  templateUrl: './fix-appointment.component.html',
  styleUrls: ['./fix-appointment.component.css']
})
export class FixAppointmentComponent implements OnInit, OnChanges {
  AppointForm: any;
  Appoint: any;
  Appoints: any;
  @Input() doctorId: any;
  doctorList: any;
  isAuth:boolean=false;
  constructor(private fb: FormBuilder, private fb1: AppointmentService, private doctorService: PhysicianService, private router: Router) {
    this.AppointForm = this.fb.group({
      doctorId: ['', Validators.required],
      appointmentDate: ['', Validators.required],
      timeSlot: ['', Validators.required],
      description: ['', Validators.required],
      treatmentId: ['', Validators.required]
    });
  }
  ngOnChanges(changes: SimpleChanges): void {
    console.log(this.doctorId);
  }

  ngOnInit(): void {
    if(localStorage.getItem("id")!=null){
      this.isAuth=true;
    }
    this.doctorService.getAllPhysician().subscribe(data => { this.doctorList = data; console.log(data) });
  }
  fnCreateAppoint() {
  
    this.Appoint = this.AppointForm.value;
    let result: any;
    let id=Number(localStorage.getItem("id"))
    this.fb1.create(id,this.Appoint).subscribe(data => {
     window.location.replace("/my-appointment")
    });
  
  }
  get formControl() {
    return this.AppointForm.controls;
  }
}
