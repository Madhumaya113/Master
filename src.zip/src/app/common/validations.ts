import { FormGroup } from "@angular/forms";

export function dateExpected(pastDate:boolean,controlName:string) {
    return (formGroup:FormGroup)=>{
        // alert("hii");
        const date = formGroup.controls[controlName];
        var dateLiterals = date.value.split('-');
        var today = new Date(Date.now());
        if (date.errors && !date.errors.unexpectedDate) {
            // return if another validator has already found an error on the matchingControl
            return;
        }
        if(!pastDate){
            if(today.getFullYear() > parseInt(dateLiterals[0])) {
                date.setErrors({unexpectedDate:true})
            } else {
                if(today.getMonth()+1 > parseInt(dateLiterals[1])) {
                    date.setErrors({unexpectedDate:true})
                } else {
                    if (today.getDate() > parseInt(dateLiterals[2])) {
                        date.setErrors({unexpectedDate:true})
                    } else {
                        date.setErrors(null);
                    }
                }
            }
        } else {
            if(today.getFullYear() < parseInt(dateLiterals[0])) {
                date.setErrors({unexpectedDate:true})
            } else {
                console.log(today.getMonth());
                if(today.getMonth()+1 < parseInt(dateLiterals[1])) {
                    date.setErrors({unexpectedDate:true})
                } else {
                    if (today.getDate() < parseInt(dateLiterals[2])) {
                        date.setErrors({unexpectedDate:true})
                    } else {
                       date.setErrors(null);
                    }
                } 
            }
        }  
    }
}


export function MustMatch(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
        const control = formGroup.controls[controlName];
        const matchingControl = formGroup.controls[matchingControlName];

        if (matchingControl.errors && !matchingControl.errors.mustMatch) {
            // return if another validator has already found an error on the matchingControl
            return;
        }

        // set error on matchingControl if validation fails
        if (control.value !== matchingControl.value) {
            matchingControl.setErrors({ mustMatch: true });
        } else {
            matchingControl.setErrors(null);
        }
    }
}