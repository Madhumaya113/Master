import { Component, OnInit } from '@angular/core';
import { $ } from 'protractor';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }

  carousle=[
    { url: './assets/images/carousel/home/1.jpeg', text: 'my image' },
    { url: './assets/images/carousel/home/2.jpeg', text: 'image 1' },
    { url: './assets/images/carousel/home/3.jpg', text: 'image 2' },
    { url: './assets/images/carousel/home/4.jpg', text: 'image 3' }
  ];

  departmentsCard=[
    {url:'./assets/images/departments/gmed.png',title:'General Medicine'},
    {url:'./assets/images/departments/gm.png',title:'General Surgery'},
    {url:'./assets/images/departments/ped.png',title:'Pediatrics and Neonatology'},
    // {url:'./assets/images/departments/ent.png',title:'ENT Care'},
    // {url:'./assets/images/departments/pain.png',title:'Orthopedic Specialists'},
    {url:'./assets/images/departments/cardio.png',title:'Cardiology'},
    {url:'./assets/images/departments/gync.png',title:'Gynecology'},
    
  ];

  servicesCard=[
    {url:'./assets/images/departments/pul.png',title:'Pulmonary Medicine'},
    {url:'./assets/images/departments/neuro.png',title:'Neurology'},
    {url:'./assets/images/departments/psy.png',title:'psychiatry '},
    {url:'./assets/images/departments/ent.png',title:'ENT Care'},
    // {url:'./assets/images/departments/pain.png',title:'Orthopedic Specialists'},
    {url:'./assets/images/departments/derm.png',title:'Dermatology'},
    {url:'./assets/images/departments/onco.png',title:'Oncology'},
  ];
  ngOnInit(): void {
    
  }

}
