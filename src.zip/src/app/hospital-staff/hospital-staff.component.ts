import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hospital-staff',
  templateUrl: './hospital-staff.component.html',
  styleUrls: ['./hospital-staff.component.css']
})
export class HospitalStaffComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
