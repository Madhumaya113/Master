import { Component, OnInit} from "@angular/core";
import { FormBuilder, Validators } from "@angular/forms";

@Component({
    templateUrl: './staff-login.component.html',
    selector:'staff-login'
   // styleUrls: ['./staff-login.component.css']
})

export class StaffLoginComponent implements OnInit{
    loginForm: any;
  constructor(private formBuilder: FormBuilder) {
    this.loginForm = this.formBuilder.group({
      userName: ['', [Validators.required]],
      password: ['', [Validators.required]]
    })
  }
  ngOnInit(): void { }
  fn1() {
    alert(JSON.stringify(this.loginForm.value));
  }
  get formControl() {
    return this.loginForm.controls;
  }
}