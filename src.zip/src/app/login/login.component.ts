import { flatten } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  invalidCredentials:boolean=false;
  loginForm: any;
  data:any;
  constructor(private formBuilder: FormBuilder,private service:UserService,private router:Router) {
    this.loginForm = this.formBuilder.group({
      userName: ['', [Validators.required]],
      password: ['', [Validators.required]]
    })
  }
  ngOnInit(): void { }
  fn1() {
    this.service.login(this.loginForm.value).subscribe(data=>{
      if(data==null)
        this.invalidCredentials=true;
      else{
        this.data=data;
        console.log();
        localStorage.setItem("id",this.data.id);
        localStorage.setItem("user_role",this.data.user_role);
       window.location.replace("/home");
      }
    })
  }
  get formControl() {
    return this.loginForm.controls;
  }

}
