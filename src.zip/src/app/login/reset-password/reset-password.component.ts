import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {
  msg:any;
  forgetForm:any; 
  constructor(private formBuilder:FormBuilder, private os:UserService) { 
    this.forgetForm = this.formBuilder.group({
      email:['', [Validators.required, Validators.email]],
      otp: ['', [Validators.required]],
      password:['',[Validators.required, Validators.pattern('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$')]]
      
    });
  }

  ngOnInit(): void {
  }

    onGenerate(){
      console.log("hii");
      var email= this.forgetForm.controls.email.value;
      this.os.sendOtp(email).subscribe(data=>console.log((data)))
    }
  
    onSubmit(){
  
      var email = this.forgetForm.controls.email.value;
      var password = this.forgetForm.controls.password.value;
      var otp = this.forgetForm.controls.otp.value;
      alert("entered enter function")
      alert(email)
      alert(password)
      alert(otp)
  
      this.os.enterOtp(email,otp,password).subscribe(data=>{
        alert(data);
        
      })
     
    }  
      
}
