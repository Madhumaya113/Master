import { Component, Input, OnInit } from "@angular/core";
@Component({
    selector:'navbar-left',
    templateUrl:'./navbar-left.component.html',
    styleUrls:['./navigation-bar.component.css']
})
export class NavbarLeftComponent implements OnInit{
    @Input()userProfile:string="Guest";
    @Input()current:String='/home';
    ngOnInit():void{
    //  switch (this.userProfile){
    //      case String:
    //      {

    //      }
        
     }
}

    
