import { Component, Input, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { UserService } from "../services/user.service";

@Component({
    selector:'navbar-right',
    templateUrl:'navbar-right.component.html'
})

export class NavbarRightComponent implements OnInit {
    @Input() isAuth:boolean=false;
    @Input() userProfile:string="";
    @Input() current:String="";
    profileUrl="";
    constructor(private service:UserService,private route:Router){}
    ngOnInit(): void {
        switch(this.userProfile){
            case 'Patient':this.profileUrl="/patient-profile";break;
            case 'Physician':this.profileUrl="/physician-profile";break;
            case 'Admin':this.profileUrl="/admin-profile";break;
            case 'Staff':this.profileUrl="/staff-profile";break;
          }
    }
    logout(){
       localStorage.clear();
      window.location.replace("/home");
    }
}