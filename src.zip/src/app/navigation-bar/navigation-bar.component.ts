import { Component, OnInit } from '@angular/core';
import {Router,NavigationEnd} from '@angular/router';
import { UserService } from '../services/user.service';
@Component({
  selector: 'navigation-bar',
  templateUrl: './navigation-bar.component.html',
  styleUrls: ['./navigation-bar.component.css']
})
export class NavigationBarComponent implements OnInit {
  isLogin: boolean = false;
  userProfile: any = "Guest";
  ProfileUrl: string = "";
  urlEnd:String='';
  constructor(private router:Router,private user:UserService) {
    router.events.subscribe(event=>{
      if(event instanceof NavigationEnd){
        this.urlEnd=event.urlAfterRedirects;
      }
    });
  }

  ngOnInit(): void {
    console.log(localStorage.getItem("id"))
    if(localStorage.getItem("id")==null||localStorage.getItem("user_role")==null)
    {
      this.isLogin=false;
    }
    else
    {
      console.log("called")
      this.isLogin=true;
      this.userProfile=localStorage.getItem("user_role");
      
    }
  }
}
