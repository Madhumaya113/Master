import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'patient-login',
  templateUrl: './patient-login.component.html',
  styleUrls:['../patient.component.css']
})
export class PatientLoginComponent implements OnInit {
  loginForm: any;
  constructor(private formBuilder: FormBuilder) {
    this.loginForm = this.formBuilder.group({
      userName: ['', [Validators.required]],
      password: ['', [Validators.required]]
    })
  }
  ngOnInit(): void { }
  fn1() {
    alert(JSON.stringify(this.loginForm.value));
  }
  get formControl() {
    return this.loginForm.controls;
  }
}
