import { Component, OnInit } from "@angular/core";
import { FormBuilder, Validators } from "@angular/forms";
import { PatientService } from "src/app/services/patient.service";

@Component({
  selector: 'patient-profile',
  templateUrl: './patient-profile.component.html'
})

export class PatientProfileComponent implements OnInit {
    patient:any;
    profileForm: any;
    pageTitle: string = 'PATIENT PROFILE';
    btnText: string = "Update";
    isSignUp: boolean = true;
    date:Date=new Date(Date.now());
    today="";
    constructor(private formBuilder: FormBuilder,private service : PatientService) {
  
      this.profileForm = this.formBuilder.group({
        firstName: ["", [Validators.required, Validators.minLength(3)]],
        lastName: ['', [Validators.required]],
        email: ['', [Validators.required, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]],
        dateOfBirth: ['', [Validators.required]],
        gender: ['', [Validators.required]],
        contactNo: ['', [Validators.required, Validators.pattern("[6-9]{1}[0-9]{9}"), Validators.minLength(10), Validators.maxLength(10)]],
        address: ['', [Validators.required]],
        bloodGroup: ['', [Validators.required]]
      },{
        // validators: [MustMatch('password','confirmPassword'),dateExpected(true,'dob')],
      })
  
    }
    ngOnInit(): void {
      let id = Number(localStorage.getItem("id"));
      this.today =this.date.getFullYear()+ "-" +(this.date.getMonth()+1)+ "-" +this.date.getDate();
      this.service.getPatientById(id).subscribe(data => { this.patient = data; 
        console.log(data) 
      this.profileForm.patchValue(this.patient)
    
    })
     }
    get formControl() {
      return this.profileForm.controls;
    }
    f1() {
      console.log(this.profileForm.value)
     this.service.upadtePatient(420,this.profileForm.value).subscribe(data=>{
       alert(JSON.stringify(data));
     });
     
    }
  }
