import { Component, OnInit } from "@angular/core";
import { FormBuilder, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { PatientService } from "src/app/services/patient.service";
import { MustMatch ,dateExpected} from '../../common/validations';
@Component({
  selector: 'patient-signup',
  templateUrl: './patient-signup.component.html'
})

export class PatientSignupComponent implements OnInit {
  signupForm: any;
  pageTitle: string = 'PATIENT SIGN UP';
  btnText: string = "Sign up";
  isSignUp: boolean = true;
  date:Date=new Date(Date.now());
  today="";
  constructor(private formBuilder: FormBuilder,private service : PatientService,private router:Router) {

    this.signupForm = this.formBuilder.group({
      firstName: ["", [Validators.required, Validators.minLength(3)]],
      lastName: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]],
      dateOfBirth: ['', [Validators.required]],
      gender: ['', [Validators.required]],
      contactNo: ['', [Validators.required, Validators.pattern("[6-9]{1}[0-9]{9}"), Validators.minLength(10), Validators.maxLength(10)]],
      address: ['', [Validators.required]],
      password: ['', [Validators.required]],
      bloodGroup: ['', [Validators.required]],
      confirmPassword: ['', [Validators.required]]
    },{
      // validators: [MustMatch('password','confirmPassword'),dateExpected(true,'dob')],
    })

  }
  ngOnInit(): void {
    this.today =this.date.getFullYear()+ "-" +(this.date.getMonth()+1)+ "-" +this.date.getDate();
   }
  get formControl() {
    return this.signupForm.controls;
  }
  f1() {
    console.log(this.signupForm.value)
   this.service.addPatient(this.signupForm.value).subscribe(data=>{
      if(data){
        this.router.navigateByUrl("/login");
      }
   });
  }
}