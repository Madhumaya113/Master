import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { AppointmentService } from 'src/app/services/appointment.service';
import { PatientService } from '../../services/patient.service';

@Component({
  selector: 'app-appointment-form',
  templateUrl: './appointment-form.component.html',
  styleUrls: ['./appointment-form.component.css']
})
export class AppointmentFormComponent implements OnInit {
  Appoint: any;
  Appoints: any;
  AppointForm: any;
  isLoading = true;
  constructor(private fb: FormBuilder, private service: AppointmentService) {
    this.AppointForm = this.fb.group({
      doctor: ['', Validators.required],
      date: ['', Validators.required],
      timeslot: ['', Validators.required],
      description: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    let id=Number(localStorage.getItem("id"))
    console.log(id)
    this.service.viewAppointmentByPatientId(id).subscribe(data => { this.Appoints = data; console.log(data) })
    this.isLoading = true;
  }
  get formControl() {
    return this.AppointForm.controls;
  }

}
