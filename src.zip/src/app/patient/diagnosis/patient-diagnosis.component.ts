import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patient-diagnosis',
  templateUrl: './patient-diagnosis.component.html',
  styleUrls: ['./patient-diagnosis.component.css']
})
export class PatientDiagnosisComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
