export {PatientLoginComponent} from './account/patient-login.component';
export {PatientSignupComponent} from './account/patient-signup.component';
export {PatientComponent} from './patient.component';
export {PatientProfileComponent} from './account/patient-profile.component';
export {PatientReportComponent} from './report/patient-report.component';
export {PatientDiagnosisComponent} from './diagnosis/patient-diagnosis.component';
export {AppointmentFormComponent as PatientAppointments} from './appointment/appointment-form.component';