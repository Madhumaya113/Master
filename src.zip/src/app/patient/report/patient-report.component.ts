import { Component, OnInit } from '@angular/core';
import { PatientService } from 'src/app/services/patient.service';
import { ReportService } from 'src/app/services/report.service';

@Component({
  selector: 'app-patient-report',
  templateUrl: './patient-report.component.html',
  styleUrls: ['./patient-report.component.css']
})
export class PatientReportComponent implements OnInit {

  reports:any;
  constructor(private service:ReportService) { }

  ngOnInit(): void {
    let id = Number(localStorage.getItem("id"))
    this.service.viewPatientReports(id).subscribe(data=>{
      console.log(data)
      this.reports=data
    })
  }
  // fn1(){
  //   this.service.sendData().subscribe(data=>console.log(data));
  // }
}
