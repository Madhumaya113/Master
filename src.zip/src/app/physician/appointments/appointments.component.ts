import { Component, OnInit } from '@angular/core';
import { PhysicianService } from 'src/app/services/physician.service';

@Component({
  selector: 'app-appointments',
  templateUrl: './appointments.component.html',
  styleUrls: ['./appointments.component.css']
})
export class AppointmentsComponent implements OnInit {
  appointmentList:any;
  constructor(private service:PhysicianService) { }

  ngOnInit(): void {
    this.getAllAppointmentsList();
  }
  getAllAppointmentsList(){
    this.service.getAppoint(20).subscribe(data=>{this.appointmentList=data;console.log(data)});
  }
}
