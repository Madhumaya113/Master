export {PhysicianComponent} from './physician.component';
export {AppointmentsComponent as PhysicianAppointments} from './appointments/appointments.component';