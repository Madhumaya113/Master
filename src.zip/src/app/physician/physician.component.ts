import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { PhysicianService } from '../services/physician.service';

@Component({
  selector: 'app-physician',
  templateUrl: './physician.component.html',
  styleUrls: ['./physician.component.css'],
})
export class PhysicianComponent implements OnInit {
  doctorSearchForm:any
  physicianList:any;
  selectedDoctor:any;
  doctor:any;
  queryPhycisianName='';
  queryPhysicianSpec='';
  isDataPresent:boolean=true;
  constructor(private myService:PhysicianService,private fb:FormBuilder,private activatedRoute:ActivatedRoute,private router:Router) {
    this.activatedRoute.queryParams.subscribe(data=> {
                 this.queryPhysicianSpec=data.spec;
                 this.queryPhycisianName=data.name;
    });
    this.doctorSearchForm=this.fb.group({ 
                    name:['',[Validators.required]]
        });
  }

  ngOnInit(): void {
    this.fetchData();
  }
  get formControl() {
    return this.doctorSearchForm.controls;
  }

  fnSubmit(){
    let dname=this.doctorSearchForm.controls.name.value;
    if(dname!='')
    {
      this.router.navigate(['/doctor-list'],{ queryParams: { name: dname }}); 
      this.myService.getAllPhysicianByName(dname).subscribe(data=>{
  
        this.physicianList=data;
      });
    }
  }


  fnSelect(id:any){
    this.selectedDoctor=id;
  }

  fetchData(){
    if(this.queryPhycisianName!=undefined||this.formControl.name.value!='')
    this.myService.getAllPhysicianByName(this.queryPhycisianName).subscribe(data=>{
  
      this.physicianList=data;
    });
    else if(this.queryPhysicianSpec!=undefined)
    this.myService.getAllPhysicianBySpec(this.queryPhysicianSpec).subscribe(data=>{this.physicianList=data;console.log(data)});
    else
    this.myService.getAllPhysician().subscribe(data=>{this.physicianList=data;console.log(data)});
  }
}
