import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'contact'
})
export class ContactPipe implements PipeTransform {

  transform(value:String): String {
    return value.substr(0,3)+" "+value.substr(3,3)+value.substr(5,4);
  }

}
