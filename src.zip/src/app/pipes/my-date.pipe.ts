import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'myDate'
})
export class MyDatePipe implements PipeTransform {

  transform(value: string):Date {
    let date = new Date();
    let data=value.split(":");
    date.setHours(Number(data[0]))
    date.setMinutes(Number(data[1]))
    return date;
  }

}
