import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PrescriptionService {
  url="http://localhost:8080/prescription/"
  constructor(private http:HttpClient) { }
  insertPrescription(prescription: any){
    return this.http.post(this.url,prescription);
  }
  viewPrescription(){
    return this.http.get(this.url)
  }
  viewPatientPrescription(id:number){
    return this.http.get(this.url+"find?id="+id)
  }
  viewPrescriptionById(id:number){
    return this.http.get(this.url+id)
  }
  updatePrescription(prescription :any){
    return this.http.put(this.url,prescription)
  }
  deletePrescription(prescription :any){
    return this.http.delete(this.url,prescription)
  }
}
