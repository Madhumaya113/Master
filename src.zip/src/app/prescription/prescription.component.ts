import { Component, OnInit } from '@angular/core';
import { PrescriptionService } from '../prescription.service';

@Component({
  selector: 'app-prescription',
  templateUrl: './prescription.component.html',
  styleUrls: ['./prescription.component.css']
})
export class PrescriptionComponent implements OnInit {
  prescriptions:any;
  constructor(private service:PrescriptionService) { }

  ngOnInit(): void {
    let id = Number(localStorage.getItem("id"));
    this.service.viewPatientPrescription(id).subscribe(data=>{
      console.log(data);
      this.prescriptions=data
    })
  }

}
