import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AppointmentService {
  url = "http://localhost:8080/appointment/"
  constructor(private http: HttpClient) {
   }
   create(id:number,appointment : any){
     console.log("hiii"+appointment);
     return this.http.post(this.url+id, appointment);
   }
   view(){
     return this.http.get(this.url);
   }
   viewById(id:number){
     return this.http.get(this.url+id);
   }
   update(appointment: any){
     return this.http.put(this.url,appointment);
   }
   delete(appointment: any){
     return this.http.delete(this.url,appointment);
   }
   viewAppointmentByPatientId(id: number)
   {
    return this.http.get(this.url+"find?patient="+id);
   }
   cancelAppointment(id:number){
     return this.http.get(this.url+id);
   }
   fixAppointment(appointment:any){
     return this.http.post(this.url+"reshedule",appointment);
   }
}
