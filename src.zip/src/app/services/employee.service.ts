import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  url="http://localhost:8080/employee/";
  constructor(private http:HttpClient) { }
  addEmployee(employee :any){
   return this.http.post(this.url,employee);
  }
  getEmployeeList(){
    return this.http.get(this.url);
  }
  getEmployee(id:number){
    return this.http.get(this.url+id);
  }
  updateEmployee(employee:any){
    return this.http.put(this.url,employee);
  }
  deleteEmployee(id:any){
    return this.http.delete(this.url+id);
  }
  getUnmappedEmployee(){
    return this.http.get(this.url+'find-unmapped')
  }
  
  // getData(){
  //   return this.http.get()
  // }
}
