import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PatientService {

  url = "http://localhost:8080/patient/";
  constructor(private http: HttpClient) { }

  sendData(){
    return this.http.get(this.url+'add');
  }
  getPatientById(id:number){
    return this.http.get(this.url+id);
  }
  getPatient() {
    return this.http.get(this.url);
  }
  addPatient(data: any) {
    return this.http.post(this.url, data);
  }
  upadtePatient(id: number, data: any) {
    return this.http.put(this.url + id, data);
  }
  deletePatinet(id: number) {
    return this.http.delete(this.url + id);
  }
  // update(id: number, data: any) {
  //   return this.http.patch(this.url + id, data);
  // }
  getAppoint() {
    return this.http.get("http://localhost:3000/appoint/");
  }
  getAppointById(id: any) {
    return this.http.get("http://localhost:3000/appoint/" + id);
  }
  createAppoint(doctor: any) {
    return this.http.post("http://localhost:3000/appoint/", doctor);
  }
}
