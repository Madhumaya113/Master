import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PhysicianService {

  url:string="http://localhost:8080/doctor/find";
  constructor(private http:HttpClient) { }

  getAllPhysician(){
    return this.http.get(this.url);
  }
  getAppoint(id:number) {
    return this.http.get("http://localhost:8080/doctor/appointment?doctor="+id);
  }
  getAllPhysicianByName(name : string){
    return this.http.get(this.url+"?name="+name);
  }
  getAllPhysicianBySpec(spec : string){
    return this.http.get(this.url+"?specialization="+spec);
  }
    url2="http://localhost:8080/doctor/";
   
    addDoctor(doctor :any){
     return this.http.post(this.url2,doctor);
    }
    getDoctorList(){
      return this.http.get(this.url2);
    }
    getDoctorById(id:number){
      return this.http.get(this.url2+id);
    }
    updateDoctor(doctor:any){
      return this.http.put(this.url2,doctor);
    }
    getDoctorName(empId:any){
      return this.http.get(this.url2+empId);
    }

  
}
