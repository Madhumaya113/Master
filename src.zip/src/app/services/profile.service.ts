import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { profile } from 'console';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {
    url="http://localhost:8080/profile/";
    constructor(private http:HttpClient) { }
    addProfile(profile :any){
     return this.http.post(this.url,profile);
    }
    getProfileList(){
      return this.http.get(this.url);
    }
    getProfile(id:number){
      return this.http.get(this.url+id);
    }
    updateProfile(profile:any){
      return this.http.put(this.url,profile);
    }
    deleteProfile(id:number){
      return this.http.delete(this.url+id);
    }
  }
  