import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class QualificationService {
  url="http://localhost:8080/qualification/";
  constructor(private http:HttpClient) { }
  addQualification(id:number,qualification :any) {
    return this.http.post("http://localhost:8080/qualification/"+id,qualification);
  }

  updateQualification(id :number,qualification :any) {
    return this.http.post("http://localhost:8080/qualification/"+id,qualification);
  }

  getQualifications(id:number) {
    return this.http.get(this.url+"find?empId="+id);
  }

  deleteQualification(id :any) {
    return this.http.delete(this.url+id);
  }
  getQualificationList(){
    return this.http.get(this.url);
  }
}
