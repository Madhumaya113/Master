import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ReportService {
  url="http://localhost:8080/report/"
  constructor(private http:HttpClient) { }
  insertReport(report: any){
    return this.http.post(this.url,report);
  }
  viewReport(){
    return this.http.get(this.url)
  }
  viewPatientReports(id:number){
    return this.http.get(this.url+"find?id="+id)
  }
  viewReportById(id:number){
    return this.http.get(this.url+id)
  }
  updateReport(report :any){
    return this.http.put(this.url,report)
  }
  deleteReport(report :any){
    return this.http.delete(this.url,report)
  }
}
