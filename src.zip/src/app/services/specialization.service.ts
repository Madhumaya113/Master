import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SpecializationService {
  url="http://localhost:8080/specialization/";
  constructor(private http:HttpClient) { }
  getSpecializationList(){
    return this.http.get(this.url);
  }
  getSpecialization(id:number){
    return this.http.get(this.url+id);
  }
  updateSpecialization(specialization:any){
    return this.http.put(this.url,specialization);
   }
   addSpecialization(specialization:any){
    return this.http.put(this.url,specialization);
   }
   deleteSpecialization(specialization:number){
     return this.http.delete(this.url+specialization);
   }
}
