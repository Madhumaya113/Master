import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor(private http:HttpClient) { }
  login(user:any){
    return this.http.post("http://localhost:8080/user/auth",user);
  }
  logout(){
    return this.http.get("http://localhost:8080/user/auth/logout");
  }
  getLoggedinUser(){
    return this.http.get("http://localhost:8080/user/auth/find");
  }
  sendOtp(otp:any)
  {
    alert("called");
    return this.http.get("http://localhost:8080/user/forget-password/"+otp);
  }
  //checking otp and reset password
  enterOtp(email : any ,otp:any,password:any){
    return this.http.get("http://localhost:8080/user/reset-password?email="+email+'&password='+password+'&otp='+otp);
  }
}
