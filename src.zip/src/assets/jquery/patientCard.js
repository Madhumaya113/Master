$('.my-card-js').hover(
    function (){
        alert("hii");
    }
);